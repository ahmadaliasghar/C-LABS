#include <iostream>
using namespace std;
int main()
{
	float CGPA;
	char gender;
	
	cout << "Enter your CGPA: ";
	cin >> CGPA;
	
	if(CGPA>3)
	{
		cout << "Enter your Gender: ";
		cin >> gender;
		
		if((CGPA>3.5)&&(gender=='m'))
		{
			cout << "\nYou are eligible for scholarship";
		}
		
		
		else if((CGPA>3)&&(gender=='f'))
		{
			cout << "\nYou are eligible for scholarship";
		}
		
		else
			cout << "\nYou are not eligible for scholarship";
	}
	
	else
		cout << "\nYou are not eligible for scholarship";
		
	return 0;	
}
