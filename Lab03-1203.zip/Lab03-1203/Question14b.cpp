#include <iostream>
using namespace std;
int main()
{
	int firstNo;
	int secondNo;
	
	char choice;
	
	cout << "Enter 2 integers: ";
	cin >> firstNo >> secondNo;
	
	cout << "Enter Operator: ";
	cin >> choice;
	
	switch(choice)
	{
	
		case '+':
			cout << firstNo << " + " << secondNo << " = " <<firstNo+secondNo;
			break;
	
	
		case '-':
			cout << firstNo << " - " << secondNo << " = " <<firstNo-secondNo;
			break;
	
	
		case '/':
			cout << firstNo << " / " << secondNo << " = " <<firstNo/secondNo;
			break;
	
		case '*':
			cout << firstNo << " * " << secondNo << " = " <<firstNo*secondNo;
			break;
	
	
		case '%':
			cout << firstNo << " % " << secondNo << " = " <<firstNo%secondNo;
			break;
			
		default:
			cout << "Invalid Operator!!!";
			break;
	}
	
	return 0;
	
}
