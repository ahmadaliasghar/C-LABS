#include <iostream>
using namespace std;
int main()
{
	char vowel;
	
	cout<<"Enter a vowel:\t";
	cin >> vowel;
	
	if(vowel=='a')
		cout<<"Ahmad"; 
	
	else if(vowel=='e')
		cout<<"Ehtisham";
		
	else if(vowel=='i')
		cout<<"Irtaza";
	
	else if(vowel=='o')
		cout<<"Owais";
	
	else if(vowel=='u')
		cout<<"Umar";
		
	else
		cout << "Not a vowel!!!";
		
	return 0;
}
	
