#include <iostream>
using namespace std;
int main()
{
	cout << "BMI Calculator\n\n";
	float weight;
	float height;
	float BMI;
	
	
	
	cout << "Enter weight in kilograms: ";
	cin >> weight;
	
	
	cout << "Enter height in meters: ";
	cin >> height;
	
	
	BMI = weight/(height*height);
	
	cout << "BMI = " << BMI << endl;

	
	if(BMI<18.5)
	{ 
		cout << "\nYou are Underweight";
	}
	
	
	if(BMI>=18.5&&BMI<=24.9)
	{ 
		cout << "\nYou are Normal";
	}
	
	
	if(BMI>25&&BMI<29.9)
	{ 
		cout << "\nYou are Overweight";
	}
	
	
	if(BMI>30)
	{ 
		cout << "\nYou are Obese";
	}
	
	
	return 0;
	
}
