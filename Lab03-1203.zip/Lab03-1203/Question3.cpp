#include <iostream>
using namespace std;
int main()
{
	float distance;
	
	cout << "Enter distance in kilometers: ";
	
	cin >> distance;
	
	cout << "\nDistance in miles is :" << distance*0.6213711 << " Miles";

	cout << "\nDistance in meters is :" << distance*1000 << " Meters";

	cout << "\nDistance in yards is :" << distance*1093.6133 << " yards";

	cout << "\nDistance in feets is :" << distance*3280. << " feet";

	return 0;
	
}
