#include <iostream>
using namespace std;
int main()
{
	char status;
	int weeks;
	
	cout << "Enter your status: ";
	cin >> status;
	
	cout << "Enter number of weeks: ";
	cin >> weeks;
	
	if(status=='s')
	{
		cout << "\nYour salary is = " << 800*weeks << "$";
	}
	
	
	else if(status=='j')
	{
		cout << "\nYour salary is = " << 500*weeks << "$";
	}
	
	else
		cout << "\nInvalid Status!!!";
		
	return 0;
	
}
