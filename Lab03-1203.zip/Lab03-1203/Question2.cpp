#include <iostream>
using namespace std;
int main()
{
	float rad;
	
	const float pi = 3.14159; 
	
	cout << "Enter radius of a circle = ";
	
	cin >> rad;
	
	cout << "Diameter of the circle is = " << 2*rad << endl;
	
	cout << "Area of the circle is = " << pi*rad*rad << endl;
	
	cout << "Circumference of the circle is = " << 2*pi*rad << endl;
	
	return 0;
	
}
