#include <iostream>
using namespace std;
int main()
{
	int num1;
	int num2;
	int num3;
	int num4;
	int num5;
	
	cout << "Enter 5 numbers: ";
	cin >> num1 >> num2 >> num3 >> num4 >> num5;
	
	if((num1>num2)&&(num1>num3)&&(num1>num4)&&(num1>num5))
	{
		cout << num1 << " is Maximum" << endl;
	}
	
	
	if((num2>num1)&&(num2>num3)&&(num2>num4)&&(num2>num5))
	{
		cout << num2 << " is Maximum" << endl;
	}
	
	
	if((num3>num1)&&(num3>num2)&&(num3>num4)&&(num3>num5))
	{
		cout << num3 << " is Maximum" << endl;
	}
	
	
	if((num4>num1)&&(num4>num2)&&(num4>num3)&&(num4>num5))
	{
		cout << num4 << " is Maximum" << endl;
	}
	
	
	if((num5>num1)&&(num5>num2)&&(num5>num3)&&(num5>num4))
	{
		cout << num5 << " is Maximum" << endl;
	}
	
	
	// Minimum 
	
	
	if((num1<num2)&&(num1<num3)&&(num1<num4)&&(num1<num5))
	{
		cout << num1 << " is Minimum";
	}
	
	
	if((num2<num1)&&(num2<num3)&&(num2<num4)&&(num2<num5))
	{
		cout << num2 << " is Minimum";
	}
	
	
	if((num3<num1)&&(num3<num2)&&(num3<num4)&&(num3<num5))
	{
		cout << num3 << " is Minimum";
	}
	
	
	if((num4<num1)&&(num4<num2)&&(num4<num3)&&(num4<num5))
	{
		cout << num4 << " is Minimum";
	}
	
	
	if((num5<num1)&&(num5<num2)&&(num5<num3)&&(num5<num4))
	{
		cout << num5 << " is Minimum";
	}
	
	
	
	return 0;
	
}
	
	
