#include <iostream>
using namespace std;
int main()
{
	char alphabet;
	
	cout << "Enter a chracter :  ";
	cin >> alphabet;
	
	if(alphabet>='A'&&alphabet<='Z')
		cout << alphabet << " is a large alphabet";
		
	
	if(alphabet>='a'&&alphabet<='z')
		cout << alphabet << " is a small alphabet";
	
	
	return 0;
}
