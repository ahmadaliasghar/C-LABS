#include <iostream>
using namespace std;
int main()
{
	
	int num1;
	int num2;
	
	cout << "Enter 1st integer value : ";
	cin >> num1;
	
	
	cout << "Enter 2nd integer value : ";
	cin >> num2;
	
	if(num1%num2==0)
	{
		cout << "\nYes, 1st is a multiple of 2nd";
	}
	
	if(num1%num2!=0)
		cout << "\nNo, 1st is not multiple of 2nd";
		
	return 0;
		
}

