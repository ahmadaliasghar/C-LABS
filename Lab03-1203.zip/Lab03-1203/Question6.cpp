#include <iostream>
using namespace std;
int main()
{
	int num1;
	int num2;
	
	
	cout << "Enter 1st integer value : ";
	cin >> num1;
	
	
	cout << "Enter 2nd integer value : ";
	cin >> num2;
	
	if(num1>num2)
	{
		cout << "\n" << num1 << " is greater than " << num2;
	}
	
	
	if(num1<num2)
	{
		cout << "\n" << num1 << " is smaller than "  << num2;
	}
	
	
	if(num1==num2)
	{
		cout << "\n" << num1 << " is equal to " << num2;
	}
	
	return 0;
	
}
