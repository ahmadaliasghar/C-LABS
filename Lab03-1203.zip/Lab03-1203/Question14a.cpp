#include <iostream>
using namespace std;
int main()
{
	int firstNo;
	int secondNo;
	
	char choice;
	
	cout << "Enter 2 integers: ";
	cin >> firstNo >> secondNo;
	
	cout << "Enter Operator: ";
	cin >> choice;
	
	if(choice=='+')
	{
		cout << firstNo << " + " << secondNo << " = " <<firstNo+secondNo;
	}
	
	
	else if(choice=='-')
	{
		cout << firstNo << " - " << secondNo << " = " <<firstNo-secondNo;
	}
	
	
	else if(choice=='/')
	{
		cout << firstNo << " / " << secondNo << " = " <<firstNo/secondNo;
	}
	
	
	else if(choice=='*')
	{
		cout << firstNo << " * " << secondNo << " = " <<firstNo*secondNo;
	}
	
	
	else if(choice=='%')
	{
		cout << firstNo << " % " << secondNo << " = " <<firstNo%secondNo;
	}
	
	else
		cout << "Invalid Operator!!!";
	
	return 0;
	
}
