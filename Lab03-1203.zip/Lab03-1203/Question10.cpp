#include <iostream>
using namespace std;
int main()
{
	int marks;
	
	cout << "Enter your marks in programming course\t"; 
	cin >> marks;
	
	if(marks>=60)
	{
		cout << "He is passed in the course";
	}
	else
		cout << "He is failed";
		
	return 0;
}
