#include <iostream>
using namespace std;
int main()
{
	int x;
	
	cout << "Enter a ASCII code in integer form: ";
	cin >> x;
	
	x++;
	
	cout << "x = " << static_cast<char>(x) <<endl;
	
	
	x++;
	
	cout << "x = " << static_cast<char>(x) <<endl;
	
	
	x++;
	
	cout << "x = " << static_cast<char>(x) <<endl;
	
	
	x++;
	
	cout << "x = " << static_cast<char>(x) <<endl;
	
	
	x++;
	
	cout << "x = " << static_cast<char>(x) <<endl;
	
	return 0;
}
