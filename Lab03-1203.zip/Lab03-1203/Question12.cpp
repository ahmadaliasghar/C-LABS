#include <iostream>
using namespace std;
int main()
{
	int year;
	
	cout << "Enter year:\t";
	cin >> year;
	
	if(year%4==0)
	{
		cout << "\nIt is a leap year";
	}
	else
		cout << "\nIt is not a leap year";
		
	return 0;
}
