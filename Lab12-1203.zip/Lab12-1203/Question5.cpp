#include <iostream>
using namespace std;

class Laptop
{
	private: 
		string company;
		float processorSpeed;
		string size;
	public:
		void setData(string cpy = "Dell", float ps = 2.8, string si = "800GB")
		{
			company = cpy;
			processorSpeed = ps;
			size = si;
		}
		void getData()
		{
			cout << "Enter Company Name: ";
			cin >> company;
			cout << "Enter Processor Speed: ";
			cin >> processorSpeed;
			cout << "Enter Memory Size: ";
			cin >> size;
		}
		void print()
		{
			cout << "Company:\t" << company << endl;
			cout << "Processor Speed:\t " << processorSpeed << endl;
			cout << "Memory Size:\t" << size;
		}
};

int main()
{
	Laptop pc1;
	pc1.setData();
//	pc1.getData();
	pc1.print();
}
