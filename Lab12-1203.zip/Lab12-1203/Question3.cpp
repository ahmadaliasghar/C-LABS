#include<iostream>
using namespace std;

class BOOK
{
	private:
		string ISBN;
		string title;
		string author;
		int numberOfPages;
		int pageMembers;
	public:
		void getter(string isb, string t, string a, int nop, int pm)
		{
			ISBN = isb;
			title = t;
			author = a;
			numberOfPages = nop;
			pageMembers = pm;
		}
		void print()
		{
			cout << "ISBN: " << ISBN << endl;
			cout << "Book Title: " << title << endl;
			cout << "Book Author: " << author << endl;
			cout << "Number of Pages: " << numberOfPages << endl;
			cout << "Page Members: " << pageMembers << endl;
		
		}
};

int main()
{
	BOOK book1;
	
	book1.getter("09874563", "Programing Fundamentals", "Mr. Malik Ahmad", 392, 16);
	book1.print();
	
}
