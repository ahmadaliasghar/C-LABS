#include<iostream>
using namespace std;

class  Bike
{
	private:
		string company;
		string model;
		double price;
	public:
		void setter(string cpy, string mdl, double prc)
		{
			company = cpy;
			model = mdl;
			price = prc;	
		}	
		void print()
		{
			cout << "Company:\t" << company << endl;
			cout << "Model:\t\t" << model << endl;
			cout << "Price:\t\t" << price << endl;
		}
};

int main()
{
	string comp, mod;
	double pric;
	
	cout << "Enter Company Name: ";
	cin >> comp;
	cout << "Enter Model: ";
	cin >> mod;
	cout << "Enter Price: ";
	cin >> pric;
	
	Bike bike1;
	bike1.setter(comp, mod, pric);
	bike1.print();
}

