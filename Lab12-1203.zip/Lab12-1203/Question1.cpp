#include<iostream>
using namespace std;

class Course
{
	private:
		int CourseCode;
		string	CourseTitle;
		int CreditHours;
		int OfferingSemesterMembers;
	public:
		void setData(int code, string ct, int ch, int osm)
		{
			CourseCode = code;
			CourseTitle = ct;
			CreditHours = ch;
			OfferingSemesterMembers = osm;
		}
		void getData()
		{
			cout << "Course Code: " << CourseCode << endl;
			cout << "Course Title: " << CourseTitle << endl;
			cout << "Credit Hours: " << CreditHours << endl;
			cout << "Offering Semesters: " << OfferingSemesterMembers << endl;
		}
};
int main()
{
	int courseCode, creditHours, offeringMembers;
	string courseTitle;
	
	cout << "Enter Course Code: ";
	cin >> courseCode;
	cout << "Enter Course Title: ";
	cin >> courseTitle;
	cout << "Enter creditHours: ";
	cin >> creditHours;
	cout << "Enter Offering Members: ";
	cin >> offeringMembers;
	
	Course boy1;
	boy1.setData(courseCode, courseTitle, creditHours, offeringMembers);
	boy1.getData();
}
