#include<iostream>
using namespace std;

class Teacher
{
	private:
		string TeacherID;
		string Name;
		string Qualifications;
		int DesignationMembers;
		
	public:
		void getInput()
		{
			cout << "Enter Teacher ID: ";
			cin >> TeacherID;
			cout << "Enter Teacher Name: ";
			cin >> Name;
			cout << "Enter Qualifications: ";
			cin >> Qualifications;
			cout << "Enter Designation Members: ";
			cin >> DesignationMembers;
		}
		void print()
		{
			cout << "Teacher ID: " << TeacherID << endl;
			cout << "Teacher Name: " << Name << endl;
			cout << "Qualifications: " << Qualifications << endl;
			cout << "Designation Members: " << DesignationMembers << endl;
		
		}
		
};
int main()
{
	
	Teacher teacher1;
	teacher1.getInput();
	teacher1.print();
	
	
	
}
