#include<iostream>
#include<stdlib.h>
using namespace std;
int main()
{
	char a[3]={'a','b','c'};
	
	float b[3]={1.1, 2.2, 3.3};
	
	float *ptr = b;
	char *ptr1 = a;
	
	cout << ptr << endl;
	cout<< ptr + 1 << endl;
	cout << ptr + 2 << endl;
	
	return 0;
}

