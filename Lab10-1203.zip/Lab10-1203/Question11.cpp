#include<iostream>
using namespace std;
int main()
{
	char a, b, c, *e, *f, *g;
	e = &a;
	f = &b;
	g = &c;
	cout << "Enter three characters: ";
	cin >> *e >> *f >> *g;
	cout<<"You enter character: "<< endl;
	cout << *e << endl << *f << endl << *g;
	
	return 0;
}

