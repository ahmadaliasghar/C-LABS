#include <iostream>
using namespace std;
int main() {
 	char a[3][10];
 
 	for(int i = 0; i < 3; i++)
  		cin >> a[i];
 	for(int i = 0; i < 3; i++)
 		cout << a[i] << endl;
 	
 return 0;
}
