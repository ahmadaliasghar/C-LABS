#include<iostream>
using namespace std;
int main()
{
	float a,b,c,*pt1,*pt2,*pt3,s;
	pt1=&a;
	pt2=&b;
	pt3=&c;
	cout<<"  Enter three values of pointer: ";
	cin>>*pt1>>*pt2>>*pt3;
	
	s=*pt1+*pt2+*pt3;
	
	cout<<"Average is: " << s / 3;
	
}

