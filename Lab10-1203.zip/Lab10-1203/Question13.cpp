#include<iostream>
using namespace std;
int sum(int *a,int *b,int *c){
	int add=*a+*b+*c;
	return add;
}
int main(){
	int a,b,c,*e,*f,*g;
	cout<<"Enter 3 values: ";
	cin >> a >> b >> c;
	e = &a;
	f = &b;
	g = &c;
	cout << "The sum is: " << sum(e,f,g);
	
	return 0;
}

