#include<iostream>
using namespace std;
int main(){
	int ary[4][6]={{1005,75,85,80,75,(75+85+80+75)/4},{1006,85,65,78,86,(85+65+78+86)/4},{1007,65,70,69,58,(65+70+69+58)/4},{1008,60,75,79,79,(60+75+79+79)/4}};
	
	cout<<"Student#\tProgramming\tCalculus\tLinear Algebra\tIslamic Studies\tAverage"<<endl;
	for(int i=0;i<4;i++){
		for(int j=0;j<6;j++){
			cout<<ary[i][j]<<"\t\t";
		}cout<<endl;
	}
}

