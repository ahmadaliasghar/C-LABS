#include<iostream>

using namespace std;

const int rows = 3;
const int columns = 3;
	
void input(int array[rows][columns])
{
	for(int i=0; i<rows; i++)
	{
		for(int j=0; j<columns; j++)
		{
			cout << "Enter Array Elements for [" << i << ", " << j << "]\t";
			cin >> array[i][j];
		}
	}
}

void output(int array[rows][columns])
{
	for(int k=0; k<rows; k++)
	{
		for(int m=0; m<columns; m++)
		{
			cout << array[k][m] << "\t";
		}
		cout << endl;
	}
}

int main()
{
	int array[rows][columns];
	
	input(array);
	output(array);
}
