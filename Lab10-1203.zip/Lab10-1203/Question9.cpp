#include <iostream>
using namespace std;
int main()
{
	char var = 'A';
	int var1 = 5;
	
	char *ptr;
	int *ptr1;
	
	ptr = &var;
	ptr1 = &var1;
	
	cout << "Value is character variable: " << var << endl;
	cout << "Address of character variable: " << (void*)ptr << endl;
	
	cout << "\nValue is integer variable: " << var1 << endl;
	cout << "Address of integer variable: " << ptr1 << endl;
	
	
}

