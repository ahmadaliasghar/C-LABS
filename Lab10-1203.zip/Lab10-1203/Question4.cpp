/*Input a 4-by-5 array and find the minimum and maximum element from it*/

#include<iostream>
using namespace std;

int main()
{
	const int rows = 4;
	const int columns = 5;
	
	int arr[rows][columns];
	
	for(int i = 0; i < rows; i++)
	{
		for(int j = 0; j < columns; j++)
		{
			cout << "Enter element for Array " << i << ", " << j << " : " ;
			cin >> arr[i][j];
		}
	}
	
	int max = arr[0][0];
	int min = arr[0][0];
	
	//Maximum
	for(int i = 0; i < rows; i++)
	{
		for(int j = 0; j < columns; j++)
		{
			if(arr[i][j] > max)
			{
				max = arr[i][j];
			}
		}
	}
	
	//Minimum
	for(int i = 0; i < rows; i++)
	{
		for(int j = 0; j < columns; j++)
		{
			if(arr[i][j] < min)
			{
				min = arr[i][j];
			}
		}
	}
	
	cout << "\nThe Maximum element is: " << max<< endl;
	cout << "\nThe Minimum element is: " << min<< endl;

}
