#include<iostream>
using namespace std;
void swap(int *a,int *b)
{
	int temp=*a;
	*a=*b;
	*b=temp;
}
int main()
{
	int c, d;
	cout<<"Enter 2 Values: ";
	cin >> c >> d;
	swap(&c, &d);
	cout << "After Swapping: " << endl;
	cout << c << endl << d;

	return 0;
}

