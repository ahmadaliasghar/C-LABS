#include<iostream>
using namespace std;
int main()
{
	float arr1[5];
	float arr2[5];
	
	cout << "Enter 5 Numbers: ";
	cin >> arr1[0] >> arr1[1] >> arr1[2] >> arr1[3] >> arr1[04];
	
	arr2[0] = arr1[0];
	arr2[1] = arr1[1];
	arr2[2] = arr1[2];
	arr2[3] = arr1[3];
	arr2[4] = arr1[4];
	
	cout << "\nThe 5 Numbers are: " << arr2[0] << "\t"<< arr2[1] << "\t"<< arr2[2] << "\t"<< arr2[4] << "\t"<< arr2[4];
	
	
	
	return 0;
}
