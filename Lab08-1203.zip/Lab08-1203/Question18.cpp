#include <iostream>
using namespace std;
int main() {

	char arr[10];

	for (int i = 0; i < 10; i++)
	{
		cout << "Enter your grades in form of A, B, C, F: ";

		cin >> arr[i];
	}

	int a = 0, b = 0, c = 0, f = 0;

	for (int i = 0; i < 10; i++) {
		if (arr[i] == 'A') {
			a = a + 1;
		}
		if (arr[i] == 'B') {
			b = b + 1;
		}
		if (arr[i] == 'C') {
			c = c + 1;
		}
		if (arr[i] == 'F') {
			f = f + 1;
		}
	}
	cout << endl;
	
	cout << a << " students got A grade" << endl;
	cout << b << " students got B grade" << endl;
	cout << c << " students got C grade" << endl;
	cout << f << " students are failed." << endl;

	return 0;
}
