#include <iostream>
using namespace std;
int  main()
{
	char arr[5] = {'A', 'B', 'C', 'D', 'E'};
	char arr1[5];
	
	cout << "Enter values for second array: ";
	cin >> arr1[0] >> arr1[1] >> arr1[2] >> arr1[3] >> arr1[4];
	
	cout << "\nFirst Array = " << arr[0] << " " << arr[1] << " " << arr[2] << " " << arr[3] << " " << arr[4] << endl;;
	cout << "Second Array = " << arr1[0] << " " << arr1[1] << " " << arr1[2] << " " << arr1[3] << " " << arr1[4] << endl;
	
	return 0;
}
