#include<iostream>
using namespace std;
int main() {
	int bound;
	cout << "Enter the boundary: ";
	cin >> bound;
	
	int fab[100] = { 0 };
	int num1, num2, num3;
	num1 = 0;
	num2 = 1;
	int i = 0;
	
	while (num1 < bound) {
		fab[i] = num1;
		num3 = num1 + num2;
		num1 = num2;
		num2 = num3;
		i++;
	}
	cout << "The Fabonacci series is: ";
	for (int i = 0; i <= 100; i++) {
		if (fab[i] == 0 && i != 0) {
			break;
		}
		cout << " " << fab[i];
	}
	return 0;
}
