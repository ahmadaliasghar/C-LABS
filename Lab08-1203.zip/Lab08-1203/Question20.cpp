#include<iostream>
using namespace std;
int main() {
	int arr[10];

	cout << "Enter 10 numbers: ";
	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}
	cout << endl << endl;
	//Descending Numbers
	cout << "In descending order" << endl;
	for (int i = 0; i < 10 - 1; i++) {
		for (int i = 0; i < 10 - 1; i++) {
			if (arr[i] < arr[i + 1]) {
				int temp = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = temp;
			}
		}
	}
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << "  ";
	}
	cout << endl << endl;
	//Ascending Numbers
	cout << "In ascending order" << endl;
	for (int i = 0; i < 10 - 1; i++) {
		for (int i = 0; i < 10 - 1; i++) {
			if (arr[i] > arr[i + 1]) {
				int temp = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = temp;
			}
		}
	}
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << "   ";
	}
	return 0;
}
