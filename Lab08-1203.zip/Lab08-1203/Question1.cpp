#include <iostream>
using namespace std;
int  main()
{
	int arr[5] = {10, 20, 30, 40, 50};
	
	cout << "The numbers are: " << endl;
	
	cout << arr[0] << endl;
	cout << arr[1] << endl;
	cout << arr[2] << endl;
	cout << arr[3] << endl;
	cout << arr[4] << endl;

	return 0;
}
