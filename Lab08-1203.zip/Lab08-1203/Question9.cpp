#include<iostream>
using namespace std;
int main()
{
	int arr[5];
	
	cout << "Enter 5 Numbers: ";
	
	for(int i = 0; i < 5; i++)
	{
		cin >> arr[i];
	}
	
	int temp, temp2;
	
	temp = arr[0];
	arr[0] = arr[4];
	arr[4] = temp;
	
	temp2 = arr[1];
	arr[1] = arr[3];
	arr[3] = temp2;
	
	cout << "The given Numbers are: ";
	
	for(int i = 0; i < 5; i++)
	{
		cout << arr[i] << " ";
	}
	
	return 0;

}
