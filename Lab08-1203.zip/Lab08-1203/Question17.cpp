#include<iostream>
using namespace std;
int main() {
	int arr[10] = {2, 3, 5, 4, 5, 4, 1, 3, 3, 3};
	int input;
	int check = 0;
	cout << "Enter the Number you want to Look: ";
	cin >> input;
	for (int i = 0; i < 10; i++) 
	{
		if (input == arr[i]) {
			check = check + 1;
		}
	}
	cout << endl;
	cout << check << " times exist in the array.";

	return 0;
}
