#include<iostream>
using namespace std;
int main() {
	int arr[5] = { 1, 23, 24, 5, 15 };
	int num1, num2;
	int check1 = 0;
	int check2 = 0;
	cout << "Enter first number : ";
	cin >> num1;
	cout << "Enter second number: ";
	cin >> num2;
	for (int i = 0; i < 5; i++) {
		if (num1 == arr[i]) {
			check1 = check1 + 1;
		}
		if (num2 == arr[i]) {
			check2 = check2 + 1;
		}
	}
	if (check1 == 0 && check2 == 0) {
		check2 = check2 + 1;
	}
	if (check1 == 0 && check2 == 0) {
		cout << endl << "value not exists" << endl;
	}
	else {
		cout << endl << num1 << " exists " << check1 << " times in the array" << endl;
		cout << endl << num2 << " exists " << check2 << " times in the array" << endl;
	}
	return 0;
}
