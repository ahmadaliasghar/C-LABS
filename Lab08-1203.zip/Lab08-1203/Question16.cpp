#include <iostream>
using namespace std;
int main()
{
	float arr[20] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
	bool check;
	float input;
	
	cout << "Enter a Value: ";
	cin >> input;
	
	for(int i = 0; i < 20; i++)
	{
		if(input==arr[i])
			check = true;
	}
	
	if(check==true)
		cout << "\nYour value exists in the array.";
	else
		cout << "\nYour value does not exist in the array.";

	
	return 0;
}
