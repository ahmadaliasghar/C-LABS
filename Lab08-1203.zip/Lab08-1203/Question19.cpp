#include<iostream>
using namespace std;
int main() {
	char arr[10];
	int input;
	int	check = 0;
	cout << "Enter first alphabet of your name: ";

	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << "  ";
		if (arr[i] == 'C') {
			check = check + 1;
		}
	}
	cout << endl;
	cout << check << " number of names start with C  " << endl;
	return 0;
}
