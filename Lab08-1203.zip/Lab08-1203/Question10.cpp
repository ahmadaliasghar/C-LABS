#include<iostream>
using namespace std;
int main()
{
	int arr[10];
	int sum = 0;
	float average;
	
	
	for(int i = 0; i < 10; i++)
	{
		cout << "Enter marks: ";
		cin >> arr[i];
		sum = sum + arr[i];
	}
	average = sum / 10;
	
	cout << "\nThe average marks are: " << average;
	
	return 0;
}
	
	
