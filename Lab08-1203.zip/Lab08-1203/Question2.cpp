#include <iostream>
using namespace std;
int  main()
{
	float arr[5] = {1.1, 2.2, 3.3, 4.4, 5.5};
	
	cout << "The numbers are: " << endl;
	
	cout << arr[0] << "\t";
	cout << arr[1] << "\t";
	cout << arr[2] << "\t";
	cout << arr[3] << "\t";
	cout << arr[4] << "\t";

	return 0;
}
