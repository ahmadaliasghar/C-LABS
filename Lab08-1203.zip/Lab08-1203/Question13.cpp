#include<iostream>
using namespace std;
int main()
{
	int arr[10];

	for (int i = 0; i < 10; i++)
	{
		cout << "Enter a Number: ";
		cin >> arr[i];

	}
	for (int j = 0; j < 10; j++)
	{
		if (arr[j] <= 20)
		{
			for (int k= 1; k<= arr[j]; k++)
				cout << "#";
			cout << "\n";
		}
		else
			cout << "Please Enter Number between 1 & 20.!!!\n";
	}
}

