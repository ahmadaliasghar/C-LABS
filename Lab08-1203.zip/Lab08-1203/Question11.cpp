#include<iostream>
using namespace std;
int main()
{
	int arr[10];
	int pass = 0, fail = 0;

	for (int i = 1; i <= 10; i++)
	{
		cout << "Enter marks of student " << i << " : ";
		cin >> arr[i];
		if (arr[i] > 50)
			pass++;
		if (arr[i] <= 50)
			fail++;
	}
	cout << "Number of Pass student is " << pass << endl;
	cout << "Number of fail student is " << fail << endl;

	return 0;
}
