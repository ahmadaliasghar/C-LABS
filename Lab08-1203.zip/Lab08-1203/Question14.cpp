#include<iostream>
using namespace std;
int main() {
	float arr[10];
	float min;
	cout << "Enter any 10 Numbers: " << endl;
	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}
	min = arr[0];

	for (int i = 0; i <= 9; i++)
	{
		if (min >= arr[i])
		{
			min = arr[i];
		}
	}

	cout << "\nThe Minimum number is: " << min << endl;
	return 0;

}

