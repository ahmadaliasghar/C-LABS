#include <iostream>
using namespace std;
int main()
{
	
	float arr[10];
	float arr2[10];
	
	cout << "Enter 10 Float Numbers: ";
	
	for(int i = 0; i < 10; i++)
	{
		cin >> arr[i];
	}
	
	for(int a = 0; a < 10; a++)
	{
		arr2[a] = arr[a];
	}
	
	cout << "\nThe given Numbers are: ";
	
	for(int m = 0; m < 10; m++)
	{
		cout << arr2[m] << " ";
	}
		
	
	
	return 0;
}
