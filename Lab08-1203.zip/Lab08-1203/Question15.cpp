#include<iostream>
using namespace std;
int main() {
	float arr[10];
	float min;
	float max;
	
	cout << "Enter any 10 Numbers: ";
	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}
	min = arr[0];
	max = arr[0];
	
	
	for (int i = 0; i <= 9; i++)
	{
		if (max <= arr[i])
		{
			max = arr[i];
		}
	}
	
	for (int i = 0; i <= 9; i++)
	{
		if (min >= arr[i])
		{
			min = arr[i];
		}
	}
	
	cout << "\nThe Minimum number is: " << min << endl;
	cout << "\nThe Maximum number is: " << max << endl;

	return 0;
}
	
	
