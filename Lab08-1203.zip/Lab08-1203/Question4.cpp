#include <iostream>
using namespace std;
int  main()
{
	float marks[7];
	
	cout << "Enter marks of student 1: ";
	cin >> marks[0];
	
	cout << "Enter marks of student 2: ";
	cin >> marks[1];
	
	cout << "Enter marks of student 3: ";
	cin >> marks[2];
	
	cout << "Enter marks of student 4: ";
	cin >> marks[3];
	
	cout << "Enter marks of student 5: ";
	cin >> marks[4];
	
	float max = marks[0];
	float min = marks[0];
	
	//Maximum Marks
	if(max<marks[0])
		max = marks[0];
		
	if(max<marks[1])
		max = marks[1];
		
	if(max<marks[2])
		max = marks[2];
		
	if(max<marks[3])
		max = marks[3];
		
	if(max<marks[4])
		max = marks[4];
		
		//Minimum Marks
		
	if(min>marks[0])
		min = marks[0];
		
	if(min>marks[1])
		min = marks[1];
		
	if(min>marks[2])
		min = marks[2];
		
	if(min>marks[3])
		min = marks[3];
		
	if(min>marks[4])
		min = marks[4];
	
	cout << "\nThe Maximum Marks is: " << max << endl;
	cout << "The Minimum Marks is: " << min << endl;
	
	return 0;
}
