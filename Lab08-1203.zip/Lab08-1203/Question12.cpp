#include<iostream>
using namespace std;
int main()
{
	int arr1[7];
	int arr2[7];

	for (int i = 0; i < 7; i++)
	{
		cout << "Enter a Number: ";
		cin >> arr1[i];
	}
	for (int k = 0; k < 7; k++)
	{
		arr2[k] = arr1[k];
		cout << arr2[k] << " ";
	}
}
