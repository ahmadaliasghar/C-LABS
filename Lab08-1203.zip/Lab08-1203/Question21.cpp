#include<iostream>
using namespace std;
int main() {
	float arr[10] = {0};

	cout << "Enter 10 float numbers: ";
	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}
	cout << endl << endl;
	//Descending Numbers
	cout << "In descending order" << endl;
	for (int i = 0; i < 10 - 1; i++) {
		for (int i = 0; i < 10 - 1; i++) {
			if (arr[i] < arr[i + 1]) {
				float temp = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = temp;
			}
		}
	}
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << "  ";
	}
	cout << endl << endl;
	//Ascending Numbers
	cout << "In ascending order" << endl;
	for (int i = 0; i < 10 - 1; i++) {
		for (int i = 0; i < 10 - 1; i++) {
			if (arr[i] > arr[i + 1]) {
				float temp = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = temp;
			}
		}
	}
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << "   ";
	}
	return 0;
}
