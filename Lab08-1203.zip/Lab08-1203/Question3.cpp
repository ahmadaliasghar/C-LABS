#include <iostream>
using namespace std;
int  main()
{
	float marks[5];
	
	cout << "Enter marks of student 1: ";
	cin >> marks[0];
	
	cout << "Enter marks of student 2: ";
	cin >> marks[1];
	
	cout << "Enter marks of student 3: ";
	cin >> marks[2];
	
	cout << "Enter marks of student 4: ";
	cin >> marks[3];
	
	cout << "Enter marks of student 5: ";
	cin >> marks[4];
	
	float average = (marks[0] + marks[1] + marks[2] + marks[3] + marks[4]) / 5;
	
	cout << "\nThe average marks are: " << average << endl;
	
	return 0;
}
