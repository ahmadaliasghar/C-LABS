#include <iostream>
using namespace std;
int main()
{
	float x;
	
	cout<<"Enter value in miles: ";
	cin>>x;
	
	cout<<"The value in kilometers is: "<<x*1.609;
	
	
	return 0;
}

