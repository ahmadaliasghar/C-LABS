#include<iostream>
using namespace std;

void value(int num1, int num2, int num3, int num4, int num5)
{
}

int main()
{
	int n1 = 0, n2 = 0, n3 = 0, n4 = 0, n5 = 0;
	cout << "Enter the five numbers =";
	cin >> n1 >> n2 >> n3 >> n4 >> n5;
	
	value(n1, n2, n3, n4, n5);
	
	int &ref1 = n1, &ref2 = n2, &ref3 = n3, &ref4 = n4, &ref5 = n5;
	
	cout << ref1 << endl << ref2 << endl << ref3 << endl << ref4 << endl << ref5 << endl;
	
	return 0;
}

