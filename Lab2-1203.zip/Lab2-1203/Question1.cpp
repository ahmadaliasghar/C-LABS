#include <iostream>
using namespace std;
int main()
{
	cout << "Conditional staetment is written as:" << endl;
	cout << "\t\"if(a==1)" << endl;
	cout << "\t\tcout<<\"The value of a\"<<\"=\"<<a;\"";
	
	return 0;
}
