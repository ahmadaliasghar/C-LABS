#include <iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter a 4 digits number: ";
	cin >> num;
	
	cout << "\nThe number is: " << num <<endl;
	
	cout << "The reverse of number is: " << num % 10;
	num = num/10;
	
	cout << num % 10;
	num = num/10;
	
	cout << num % 10;
	num = num/10;
	
	cout << num % 10;
	
	if(num%2==0){
	
		cout << "\nThe reverse of given number is Even";
	}
	else 
		cout << "\nThe reverse of given number is Odd";

	return 0;
}
