#include <iostream>
using namespace std;
int main()
{
	float x = 5.67;
	float y = 3.98;
	
	cout<<"The value of x before swapping is: "<<x<<endl;
	cout<<"The value of y before swapping is: "<<y<<endl;
	
	float temp;
	
	temp = x;
	x = y;
	y= temp;
	
   	cout<<"The value of x after Swapping is:"<<x<<endl;
   	cout<<"The value of y after Swapping is: "<<y<<endl;


	
	
	return 0;
}
