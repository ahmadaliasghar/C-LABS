#include <iostream>
using namespace std;
int main()
{
	
	char chracter;
	cout<<"Enter any chracter: ";
	cin>>chracter;
	cout<<"Chracter: "<<chracter<<endl;
	cout<<"ASCII Value = "<<static_cast<int>(chracter)<<endl;

	return 0;
}
