//Input two variables from user and display results of all 6 relational operators i.e. cout<<a>b;

#include <iostream>
using namespace std;
int main()
{
	int num1;
	int num2;
	
	cout<<"Enter first variable: ";
	cin>>num1;
	
	cout<<"Enter second variable: ";
	cin>>num2;
	
	cout<<num1<<"<"<<num2<<endl;
	cout<<num1<<">"<<num2<<endl;
	cout<<num1<<"<="<<num2<<endl;
	cout<<num1<<">="<<num2<<endl;
	cout<<num1<<"=="<<num2<<endl;
	cout<<num1<<"!="<<num2<<endl;
	
	return 0;
}
