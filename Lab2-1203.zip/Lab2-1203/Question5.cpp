#include <iostream>
using namespace std;
int main()
{
	float x;
	cout<<"Enter your height in feet: ";
	cin>>x;
	cout<<"Your height in meters is: "<<x*0.3048;
	
	return 0;
}
