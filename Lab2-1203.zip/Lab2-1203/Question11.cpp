#include <iostream>
using namespace std;
int main()
{
	int num;
	
	cout << "Enter any 4 digits number: ";
	
	cin >> num;

	cout  << "The reverse is: " << num % 10;
	num = num / 10;
	
	cout  << num % 10;
	num = num / 10;
	
	cout  << num % 10;
	num = num / 10;
	
	cout  << num % 10;
	num = num / 10;
	
	return 0;
}
