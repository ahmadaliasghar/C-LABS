#include <iostream>
using namespace std;
int main()
{
	float x;
	
	cout<<"Enter value in Pak Rupees: ";
	cin>>x;
	
	cout<<"Value in Dollars: "<<x/135<<endl;
	cout<<"Value in Ponds: "<<x/170<<endl;
	cout<<"Value in Euro: "<<x/140;
	
	
	
	return 0;
}
