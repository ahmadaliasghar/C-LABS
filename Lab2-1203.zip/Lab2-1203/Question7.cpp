#include <iostream>
using namespace std;
int main()
{
	char x = 'A';
	char y = 'B';
	
	cout<<"The value of x before Swapping is: "<<x<<endl;
	cout<<"The value of y before Swapping is: "<<y<<endl;
	
	char temp;
	
	temp = x;
	x = y;
	y = temp;
	
	cout<<"The value of x after Swapping is: "<<x<<endl;
	cout<<"The value of y after Swapping is: "<<y<<endl;

	
	
	return 0;
 } 
