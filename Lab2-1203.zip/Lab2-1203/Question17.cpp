#include <iostream>
using namespace std;
int main()
{
	char word;
	
	cout<<"Enter 'F' for first year or 'L' for last year:\t";
	cin >> word;
	
	if(word=='F')
		cout<<"You are a junior";
		
	if(word=='L')
		cout<<"You are a senior";
	
	
	
	return 0;
}
