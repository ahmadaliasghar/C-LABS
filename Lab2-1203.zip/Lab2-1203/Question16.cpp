#include <iostream>
using namespace std;
int main()
{
	char vowel;
	
	cout<<"Enter a vowel:\t";
	cin >> vowel;
	
	if(vowel=='a')
		cout<<"Ahmad"; 
	
	if(vowel=='e')
		cout<<"Ehtisham";
		
	if(vowel=='i')
		cout<<"Irtaza";
	
	if(vowel=='o')
		cout<<"Owais";
	
	if(vowel=='u')
		cout<<"Umar";	
	
	
	
	return 0;
}
