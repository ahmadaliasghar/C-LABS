#include <iostream>
using namespace std;
int main()
{
	int x;
	cout<<"Enter a 5 digits number: ";
	cin>>x;
	
	cout<<"\n"<<x/10000;
	x = x%10000;
	
	cout<<" "<<x/1000;
	x = x%1000;
	
	
	cout<<" "<< x/100;
	x = x%100;
	
	
	cout<<" "<< x/10;
	x = x%10;
	
	
	cout<<" "<< x/1;
	x = x%1;
	
	
	return 0;
	
}
