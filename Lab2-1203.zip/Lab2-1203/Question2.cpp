#include <iostream>
using namespace std;
int main()
{

int num1;
int num2;
int num3;

cout << "Input three different integers: " << endl;

cin >> num1;
cin >> num2;
cin >> num3;


cout << "\nSum is "<< (num1+num2+num3) << endl;
cout << "Average is "<< (num1+num2+num3)/3 << endl;
cout << "Product is "<< (num1*num2*num3) << endl;

	return 0;
 } 
