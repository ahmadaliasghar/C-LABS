#include <iostream>
using namespace std;
int main()
{
	int num1;
	int num2;
	
	cout << "Enter first variable: ";
	cin >> num1;
	
	cout << "Enter second variable: ";
	cin >> num2;
	
	if(num1>num2)
	{
		
		cout<<num1<<">"<<num2;
	
	}
	
	else if(num1<num2)
	{
		
		cout<<num1<<"<"<<num2;
	
	}
	
	else
	{
		
		cout<<num1<<"=="<<num2;
	
	}
	
	return 0;
	 
	 
}
