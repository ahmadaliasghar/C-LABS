#include <iostream>
using namespace std;
int main()
{
	int a;
	int x;
	int y;
	
	cout << "Enter value of a: ";
	cin >> a;
	cout << "Enter value of x: ";
	cin >> x;
	
	y = (a*x*x*x)+(a*a*x*x)+(x-7);
	
	cout << "y = " << y;
	
	return 0;
}
