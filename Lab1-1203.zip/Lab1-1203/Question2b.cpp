#include <iostream>
using namespace std;
int main()
{
	//First
	cout << "*********";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*********"<<endl;
	//Second
	cout << "   ***   ";
	cout << "\n *     *";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n*\t*";
	cout << "\n *     *";
	cout << "\n   ***   "<<endl;
	//Third
	cout << "  *  ";
	cout << "\n *** ";
	cout << "\n*****";
	cout << "\n  *  ";
	cout << "\n  *  ";
	cout << "\n  *  ";
	cout << "\n  *  ";
	cout << "\n  *  ";
	cout << "\n  *  "<<endl;
	//Fourth
	cout << "    *    ";
	cout << "\n   * *";
	cout << "\n  *   *";
	cout << "\n *     *";
	cout << "\n*\t*";
	cout << "\n *     *";
	cout << "\n  *   *";
	cout << "\n   * *";
	cout << "\n    *    "<<endl;
	return 0;
}
