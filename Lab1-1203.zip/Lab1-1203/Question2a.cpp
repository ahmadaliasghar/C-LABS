#include <iostream>
using namespace std;
int main()
{
		cout << "*********\n*\t* \n*\t* \n*\t* \n*\t* \n*\t* \n*\t* \n*\t* \n*********"<<endl;
		cout << "   ***   \n *     *\n*\t*\n*\t*\n*\t*\n*\t*\n*\t*\n *     *\n   ***   "<<endl;
		cout << "  *  \n *** \n*****\n  *  \n  *  \n  *  \n  *  \n  *  \n  *  "<<endl;
		cout << "    *    \n   * *\n  *   *\n *     *\n*\t*\n *     *\n  *   *\n   * *\n    *    "<<endl;
		
	return 0;
}
