#include <iostream>
using namespace std;
int main()
{
	cout << "Ali";
	cout << "\t21-NTU-CS-1404";
	cout << "\nAkbar";
	cout << "\t21-NTU-CS-1405";
	
	return 0;
}
