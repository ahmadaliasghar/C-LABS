#include <iostream>
using namespace std;
int main()
{
	
	char a = 'Z';
	char b = '&';
	char c = 'A';


	cout << "The value of 'a' is: " << a << endl;
	cout << "The value of 'b' is: " << b << endl;
	cout << "The value of 'c' is: " << c << endl;

	return 0;
}
