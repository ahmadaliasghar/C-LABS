#include <iostream>
using namespace std;
int main()
{
	cout << "\"The most likely way for the world to be destroyed,\n\tMost experts agree, 'is by accident'.\n\t\tThat's where we come in;\n\"We're computer professionals. We cause accidents.\"";
	
	
	cout << "\nThe most likely way for the world to be destroyed,";
	cout << "\n\tMost experts agree, 'is by accident'.";
	cout << "\n\t\tThat's where we come in;";
	cout << "\n\"We're computer professionals. We cause accidents.\""; 

	
	return 0;	
}
