#include <iostream>
using namespace std;
int main()
{
	float a = 1.5;
	float b = 4.487;
	float c = a/b;
	
	cout<<"The value of 'a' is: "<< a << endl;
	cout<<"The value of 'b' is: "<< b << endl;
	cout<<"The value of 'c' is: "<< c << endl;
	
	return 0;

}
