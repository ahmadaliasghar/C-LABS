#include <iostream>
using namespace std;
int main()
{
	int a = 15;
	int b = 4;
	int c = a/b;
	
	cout << "The value of 'a' is: "<< a << endl;
	cout << "The value of 'b' is: "<< b << endl;
	cout << "The value of 'c' is: "<< c << endl;
	
	return 0;

}
