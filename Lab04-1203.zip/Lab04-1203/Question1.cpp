#include <iostream>
using namespace std;
int main()
{
	cout << "Enter your marks in Programming Course = ";
	
	int marks;
	
	cin >> marks;
	
	(marks>=60)? cout << "\nHe is passed in the course.": cout << "\nHe is failed.";
		
	
	
	return 0;
}
