#include <iostream>
using namespace std;
int main()
{
	int num;
	
	int min = 99999;
	int max =0;
	
	for(int i = 1; i<=10; i++)
	{
		cout << "Enter Numbers : ";
		cin >> num;
		
		if(num > max)
			max = num;
		
		if(num < min)
			min = num;
		
	}
	
	cout << "\nMaximum Number = " << max << endl;
	cout << "\nMinimum Number = " << min << endl;
	
	return 0;
}
