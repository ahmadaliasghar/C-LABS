#include<iostream>
using namespace std;
int main()
{
	int num=1;
	for(int i = 1; i<=100; i++)
	{
		cout << num <<"\t";
		num++;
	}
	return 0;
}
