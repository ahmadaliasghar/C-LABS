#include<iostream>
using namespace std;
int main()
{
	int num=1;
	while(num<=100)
	{
		cout << num <<"\t";
		num++;
	}
	return 0;
}
