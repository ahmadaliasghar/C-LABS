#include <iostream>
using namespace std;
int main()
{
	int digit;
	
	
	cout << "Enter a 5 digit number : ";
	cin >> digit;

	cout << "The reverse is : ";

	
	for(int i= 1; i<=5; i++)
	{
		cout << digit % 10;
		digit = digit / 10;
		
	}
	
	return 0;
}
