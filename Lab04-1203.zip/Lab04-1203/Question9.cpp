#include<iostream>
using namespace std;
int main()
{
	int x;
	int sum;
	
	x = 1;
	sum = 0;
	
	while(x<=25)
	{
		sum = sum + x;
		cout << "Sum = " << sum <<endl;
		
		x++;
	}
	
	cout << "\nAverage is = " << sum /25 << endl;
	
	return 0;
}
