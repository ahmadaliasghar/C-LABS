#include <iostream>
using namespace std;
int main()
{
	int marks;
	
	int x =1;
	
	int add = 0;
	
	while(x<=10)
	{
		cout << "Enter marks of stuedent " << x << " : ";
		cin >> marks;
		
		add = add + marks;
		
		x++;
	}
	
	
	
	cout << "\nAverage of marks is : " << add / 10;
	
	
	
	return 0;
}
