#include <iostream>
using namespace std;
int main()
{
	int males = 0;
	int females = 0;
	char gender;
	
	for(int i = 1; i<=10; i++)
	{
		cout << "Enter your Gender : ";
		cin >> gender;
		
		if(gender=='M' || gender=='m')
		{
			males++;
		}
		
		else if(gender=='F' || gender=='f')
		{
			females++;
		}
		

	}
	
	cout << "\nNumber os Males are = " << males;
	
	cout << "\nNumber os Females are = " << females;

	
	
	return 0;
}
