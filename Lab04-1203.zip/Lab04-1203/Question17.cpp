#include <iostream>
using namespace std;
int main()
{
	int digit;
	
	int i;
	
	i = 1;
	
	cout << "Enter a 5 digit number : ";
	cin >> digit;
	
	cout << "The reverse is : ";
	
	while(i<=5)
	{
		
		cout << digit % 10;
		digit = digit / 10;
		
		
		i++;
		
	}
	
	return 0;
}
