#include<iostream>
using namespace std;
int main()
{
	int num1=0;
	int num2;
	
	cout << "Enter any number: ";
	cin >> num2;
	while(num1<=num2)
	{
		cout << num1 <<" ";
		num1++;
	}
	return 0;
}
