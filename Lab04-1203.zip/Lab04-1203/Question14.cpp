#include <iostream>
using namespace std;
int main()
{
	int num;
	int i;
	int fact;
	
	i = 1;
	fact = 1;
	
	cout << "Enter a number to calculate its factorial: ";
	cin >> num;
	
	while(i<=num)
	{
		fact = fact*i;
		i++;
	}
	
	cout << "The factorial of " << num << " is : " << fact;

	return 0;
}
