#include<iostream>
using namespace std;
int main()
{
	int num1=0;
	int num2;
	
	cout << "Enter any number: ";
	cin >> num2;
	for(int i = 0; i<=num2; i++)
	{
		cout << num1 <<" ";
		num1++;
	}
	return 0;
}
