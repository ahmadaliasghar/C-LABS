#include <iostream>
using namespace std;
int main()
{
	int num;
	int i = 1;
	int min = 9999;
	int max =0;
	
	while(i<=10)
	{
		cout << "Enter Numbers : ";
		cin >> num;
		
		if(num > max)
		{
			max = num;
		}
		
		if(num < min)
		{
			min = num;
		}
		
		i++;
	}
	
	cout << "\nMaximum Number = " << max << endl;
	cout << "\nMinimum Number = " << min << endl;
	
	return 0;
}
