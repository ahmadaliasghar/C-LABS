#include<iostream>
using namespace std;
int main()
{
	cout << "Even Numbers\n";
	
	int num = 1;
	
	for(int i = 1; i<=100; i++)
	{
		if(num%2==0)
			cout << num << "\n";
			num++;
		
	}

	cout << "\nOdd Numbers\n";
	int num1 =1;
	
	for(int i = 1; i<=50; i++)
	{

			cout << num1 << " ";
			num1 = num1 + 2;
	}
	
	
	return 0;
	
}
