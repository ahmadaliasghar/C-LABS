#include <iostream>
using namespace std;
int main()
{
	int num;
	num = 10;
	
	int fact;
	
	
	fact = 1;
	
	for(int i = 1; i<=num; i++)
	{
		fact = fact*i;
		
	}
	cout << "The factorial of 10 is: " << fact;
	
	return 0;
	
}
	
	
