#include <iostream>
using namespace std;
int main()
{
	int i;
	int males = 0;
	int females = 0;
	char gender;
	
	i = 1;
	while(i<=10)
	{
		cout << "Enter your Gender : ";
		cin >> gender;
		
		if(gender=='M' || gender=='m')
		{
			males++;
		}
		
		else if(gender=='F' || gender=='f')
		{
			females++;
		}
		
		i++;
	}
	
	cout << "\nNumber os Males are = " << males;
	
	cout << "\nNumber os Females are = " << females;

	
	
	return 0;
}
