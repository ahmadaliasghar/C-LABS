#include<iostream>
using namespace std;
int main()
{
	int num=100;
	
	for(int i = 1; i<=100; i++)
	{
		cout << num <<"\n";
		num--;
	}
	return 0;
}
