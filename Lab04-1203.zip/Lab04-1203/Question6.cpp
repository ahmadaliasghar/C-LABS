#include<iostream>
using namespace std;
int main()
{
	int num=100;
	while(num>=1)
	{
		cout << num <<"\n";
		num--;
	}
	return 0;
}
