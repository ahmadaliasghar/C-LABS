#include <iostream>
using namespace std;
int main()
{
	int i;
	i =1;
	
	while(i<=10)
	{
		cout << " 9 x " << i << " = " << 9*i << endl;
		i++;	
	} 
	
	return 0;
}
