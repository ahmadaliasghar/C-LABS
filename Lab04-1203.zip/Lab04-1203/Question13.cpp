#include <iostream>
using namespace std;
int main()
{
	int num;
	int fact;
	
	num = 10;
	fact = num;
	
	while(num>1)
	{
		num--;
		fact = fact*num;
	
	}
	
	cout << "The factorial of 10 is: " << fact;
	
	return 0;
	
}
	
	
