#include<iostream>
using namespace std;
int main()
{
	int num = 1;
	cout << "Even Numbers\n";
	
	while(num<=100)
	{
		if(num%2==0)
			cout << num << "\n";
			num++;
		
	}

	int num1 =1;
	cout << "\nOdd Numbers\n";
	
	while(num1<=100)
	{
			cout << num1 << " ";
			num1 = num1 + 2;
			
	}
	
	
	
	
	return 0;
	
}
