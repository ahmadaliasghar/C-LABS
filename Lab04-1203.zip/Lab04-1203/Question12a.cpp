#include <iostream>
using namespace std;
int main()
{
	int base;
	int power;
	int calc;
	
	
	cout << "Enter the base : ";
	cin >> base;
	
	cout << "Enter the power : ";
	cin >> power;
	
	
	for(int i; i<=power; i++)
	{
		calc = base*base;
		
	}
	
	cout << "The calculation is : " << calc;
	
	return 0;
	
}
