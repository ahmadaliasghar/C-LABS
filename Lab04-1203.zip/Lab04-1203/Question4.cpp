#include<iostream>
using namespace std;
int main()
{
	int pay;
	char gender;
	int age;
	
	cout << "Enter your basic pay:  ";
	cin >> pay;
	
	
	cout << "Enter your gender:  ";
	cin >> gender;
	
	
	cout << "Enter your age:  ";
	cin >> age;
	
	if((age>40)&&(pay>30000))
	{
		cout << "Your bonus is: " << pay*0.2 << endl;
	}
	
	else if((gender=='m')&&(age<40)&&(pay>20000))
	{
		cout << "Your bonus is: " << pay*0.15 << endl;
	}
	
	else if((gender=='f')&&(age<30)&&(pay>20000))
	{
		cout << "Your bonus is: " << pay*0.1 << endl;
	}
	
	else
		cout <<"Organization will not give bonus" << endl;
		
	return 0;
}
