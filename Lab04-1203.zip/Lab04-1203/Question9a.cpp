#include<iostream>
using namespace std;
int main()
{
	int x;
	int sum;
	
	x = 1;
	sum = 0;
	
	for(int i =1; i<=25; i++)
	{
		sum = sum + x;
		cout << "Sum = " << sum <<endl;
		
		x++;
	}
	
	cout << "Average is = " << sum /25 << endl;
	
	return 0;
}
