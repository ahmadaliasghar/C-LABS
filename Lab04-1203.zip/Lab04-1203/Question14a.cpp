#include <iostream>
using namespace std;
int main()
{
	int num;
	
	int fact;
	
	
	fact = 1;
	
	cout << "Enter a number to calculate its factorial: ";
	cin >> num;
	
	for(int i = 1; i<=num; i++)
	{
		fact = fact*i;
		
	}
	
	cout << "The factorial of " << num << " is : " << fact;

	return 0;
}
