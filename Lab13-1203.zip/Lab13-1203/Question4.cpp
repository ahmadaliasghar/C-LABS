#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	string SrNo, regNo, name, degree;
	ifstream input;
	input.open("Test.txt");
	
	if(!input)
	{
		cout<<"Error in opening file!!!!!!";
		return 0;
	}
	else
	{
		while(!input.eof())
		{
			input >> SrNo >> regNo >> name >> degree;
			cout << SrNo << "\t";
			cout << regNo << "\t";
			cout << name << "\t";
			cout << degree << "\t";
			cout << endl;
		}
	}
}
