#include<iostream>
#include<fstream>
#include<cstdlib>
using namespace std;

int main()
{
	string srno,id,name,desig,salary;
	ifstream input;
	input.open("employees.txt");
	int max = 0;
	int counter = 0;
	bool flag,flag2 = false;
	string searchid,namesearched,n2,id2;
	cout<<"Enter employe ID to search : ";
	cin>>searchid;
	cout<<"\nEnter employe NAME to search : ";
	cin>>n2;
	cout<<endl<<endl;
	while(!input.eof())
	{
		input>>srno>>id>>name>>desig>>salary;
		cout<<srno<<"\t";
		cout<<id<<"\t";
		cout<<name<<"\t";
		cout<<salary<<"\t";
		cout<<desig<<"\t";
		cout<<endl;
		counter++;
		if(searchid==id)
		{
			namesearched =name;
			flag = true;
		}
		if(n2==name)
		{
			id2 =id;
			flag2 = true;
		}
		if(atoi(salary.c_str()) > max)
		{
		    max = atoi(salary.c_str());
		}
	}
	input.close();
	cout<<"\nTotal number of empolyes : "<<counter-1<<endl;
	cout<<"\nThe highest salary company offering : "<<max;
	if(flag == true)
	{
		cout<<"\n\nThe id you searched is of :"<<namesearched;
	}
	else if(flag == false)
	{
		cout<<"\n\n*The id you entered not EXIST*";
	}
		if(flag2 == true)
	{
		cout<<"\n\nThe NAME you searched EXISTS and his id is :"<<id2;
	}
	else if(flag2 == false)
	{
		cout<<"\n\n*The NAME you entered not EXIST*";
	}
	
}
