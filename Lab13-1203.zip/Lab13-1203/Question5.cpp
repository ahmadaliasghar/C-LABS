#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	string id, name, dept, salary;
	
	ifstream input;
	input.open("employees.txt");
	
	if(!input)
	{
		cout << "Error!!!";
		return 0;
	}
	else
		while(!input.eof())
		{
			input >> id >> name >> dept >> salary;
			
			cout << id << "\t";
			cout << name << "\t";
			cout << dept << "\t";
			cout << salary << "\t";
			cout << "\n";
			
		}
	
	
}
