#include <iostream>
using namespace std;

class Book
{
	private:
		string ISBN;
		string title;
		string author;
		int numberOfPages;
		int price;
	public:
		Book(string isb, string tile, string aut, int nop, int prc)
		{
			ISBN = isb;
			title = tile;
			author = aut;
			numberOfPages = nop;
			price = prc;
		}
		
		void print()
		{
			cout << "The book ISBN is: " << ISBN << endl;
			cout << "The book title is: " << title << endl;
			cout << "The book author is: " << author << endl;
			cout << "The book number of pages are: " << numberOfPages << endl;
			cout << "The book price is: " << price << endl;

		}
			
};
int main()
{
	Book book1("12345", "The Things", "Catherine Coulter", 582, 1015);
	book1.print();
	
	cout << "\n\n--------------------------------------------------------------------------\n\n";
	
	Book *ptr = new Book("98521", "A brief history of time", "Stephan Hawkings", 368, 600);
	ptr->print();
}
