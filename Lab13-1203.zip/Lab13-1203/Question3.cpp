#include <iostream>
using namespace std;

class Mobile
{
	private:
		string company;
		string model;
		string processor;
		string camera;
	public:
		
		Mobile()
		{
			
		}
		Mobile(string comp, string mod, string proc, string cam)
		{
			company = comp;
			model = mod;
			processor = proc;
			camera = cam;
		}
		
		void print()
		{
			cout << "Mobile Company: " << company << endl;
			cout << "Mobile Model: " << model << endl;
			cout << "Mobile Processor: " << processor << endl;
			cout << "Mobile Camera: " << camera << endl;
		}
		
};

int main()
{
	Mobile arr[5];
	string company, model, processor, camera;
	
	for(int i = 0; i < 5; i++)
	{
		cout << "Enter company name: ";
		cin >> company;
		cout << "Enter mobile model: ";
		cin >> model;
		cout << "Enter mobile processor: ";
		cin >> processor;
		cout << "Enter mobile camera: ";
		cin >> camera;
		
		arr[i] = {company, model, processor, camera};
		
		cout << "\n------------------------------------\n";
	}
	
	for(int j = 0; j < 5; j++)
	{
		arr[j].print();
	}
}
