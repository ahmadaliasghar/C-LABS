#include <iostream>
using namespace std;

class Doctor
{
	private:
		int regNo;
		string name;
		string qualification;
		string speacialization;
	public:
		
		void setRegNo(int rgNum)
		{
			regNo = rgNum;
		}
		
		void setName(string naam)
		{
			name = naam;
		}
		
		void setQualifiacation(string quali)
		{
			qualification = quali;
		}
		
		void setSpeacialization(string special)
		{
			speacialization = special;
		}
		
		void print()
		{
			cout << "Registration Number = " << regNo << endl;
			cout << "Name  = " << name << endl;
			cout << "Qualifiaction = " << qualification << endl;
			cout << "Registration Number = " << speacialization << endl;
			cout << "\n--------------------------------------------\n";
		}
};

int main()
{
	Doctor arr[2];
	int regNo;
	string name, qualification, specialization;
	for(int i = 0; i < 2; i++)
	{
		cout << "Enter registration number: ";
		cin >> regNo;
		arr[i].setRegNo(regNo);
		
		cout << "Enter Doctor's Name: ";
		cin >> name;
		arr[i].setName(name);
		
		cout << "Enter Qualification: ";
		cin >> qualification;
		arr[i].setQualifiacation(qualification);
		
		cout << "Enter Specialization: ";
		cin >> specialization;
		arr[i].setSpeacialization(specialization);
		
		cout << "\n--------------------------------------------\n";
	}
	
	for(int j = 0; j < 2; j++)
	{
		arr[j].print();
	}
}
