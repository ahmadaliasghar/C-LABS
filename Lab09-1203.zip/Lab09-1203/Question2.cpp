#include<iostream>
using namespace std;
int main()
{
	int count = 0;
	char arr[] = "The most likely way for the world to be destroyed,\n\tMost experts agree,'is by accident'.\n\t\tThat where we come in;\nWe are computer professionals.We cause accidents'.";
	
	for(int i = 0; arr[i] != 0; i++)
	{
		cout << arr[i];
		count = count + 1;
	}

	cout << "\n\nTotal alphabets in the above string are: " << count << endl;
}
