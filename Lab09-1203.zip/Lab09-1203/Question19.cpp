#include <iostream>
using namespace std;

int main()
{
	int arr[4][3];
	
	cout << "Enter 12 Values for 4 x 3 Array: ";
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			cin >> arr[i][j];
		}
	}
	
	for(int i = 0; i < 3; i++)
	{
		arr[0][i] = arr[0][i] - 7;
		arr[3][i] = arr[3][i] - 7;
		
	}
	
	cout << "Values After Subtraction are: " << endl;
	
		for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	
}
