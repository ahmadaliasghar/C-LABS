#include<iostream>
using namespace std;
void menu();
void input();
void output(int[], int choice);
void large(int[]); 
void small(int[]);
void sortA(int[]);
void sortD(int[]);
void search(int[]);
const int Size=10;
int main(){
	menu();
	input();
	return 0;
}
void menu(){
	cout << "*Menu*" << endl;
	cout << "1. Large" << endl;
	cout << "2. Small" << endl;
	cout << "3. Ascending Sort" << endl;
	cout << "4. Descending Sort" << endl;
	cout << "5. Search" << endl;
}

void output(int array[Size], int choice){
	switch(choice){
		case 1:
			large(array);
			break;
		case 2:
			small(array);
			break;
		case 3:
			sortA(array);
			break;
		case 4:
			sortD(array);
			break;
		case 5:
			search(array);
			break;
		default:
			cout<<"Invalid choice";					
	}
}

void input(){
	int choice, array[Size];
	cout<<"Enter choice: ";
	cin>>choice;
	cout<<"Provide input: "<<endl;
	for(int i=0; i<Size; i++){
		cout<<"Enter "<<i+1<<" element: ";
		cin>>array[i];
	}
	output(array, choice);
}

void large(int array[Size]){
	int large;
	large=array[0];
	for(int i=0; i<Size; i++){
		if(array[i]>large){
			large=array[i];
		}
	}
	cout<<"Largest element: "<<large<<endl;
}

void small(int array[Size]){
	int small;
	small=array[0];
	for(int i=0; i<Size; i++){
		if(array[i]<small){
			small=array[i];
		}
	}
	cout<<"Smallest element: "<<small<<endl;
}

void sortA(int array[Size]){
	for(int i=0; i<Size; i++){
		for(int j=i+1; j<Size; j++){
			if(array[i]>array[j]){
				int temp=array[i];
				array[i]=array[j];
				array[j]=temp;
			}
		}
	}
	cout<<"Array in Ascending Order: ";
	for(int i=0; i<Size; i++){
		cout<<array[i]<<"\t";
	}
}

void sortD(int array[Size]){
	for(int i=0; i<Size; i++){
		for(int j=i+1; j<Size; j++){
			if(array[i]<array[j]){
				int temp=array[i];
				array[i]=array[j];
				array[j]=temp;
			}
		}
	}
	cout<<"Array in Descending Order: ";
	for(int i=0; i<Size; i++){
		cout<<array[i]<<"\t";
	}
}

void search(int array[Size]){
	int find;
	bool flag=0;
	cout<<"Enter a value to search: ";
	cin>>find;
	for(int i=0; i<Size; i++){
		if(array[i]==find){
			flag=1;
			break;
		}
	}
	if(flag){
		cout<<find<<" is found";
	}
	else{
		cout<<find<<" not found";
	}
}
