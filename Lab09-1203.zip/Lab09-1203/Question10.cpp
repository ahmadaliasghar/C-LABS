#include<iostream>
using namespace std;
int main()
{
	char arr[20];
	
	cout << "Enter your name small and large alphabets: ";
	gets(arr);
	
	cout << "Your name is: ";
	for(int i = 0; arr[i] != 0; i++)
	{
		if(arr[i] >= 'a' && arr[i] <= 'z')
		{
			arr[i] = arr[i] - 32;
		}
		
		cout << arr[i];
	}
}
