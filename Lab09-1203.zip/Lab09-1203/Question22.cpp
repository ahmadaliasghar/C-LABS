#include <iostream>
using namespace std;

int main()
{
	int arr[5][5];
	int transpose[5][5];
	
	cout << "Enter Values for 5 x 5 Array: ";
	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j < 5; j++)
		{
			cin >> arr[i][j];	
		}	
	}	
	
	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j < 5; j++)
		{
			transpose[i][j] = arr[j][i];	
		}	
	}	
	
	cout << "Transpose of 5 x 5 Array is: " << endl;
	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j < 5; j++)
		{
			cout  << transpose[i][j] << " ";	
		}	
		cout << endl;
	}	
}
