#include <iostream>
using namespace std;

int main()
{
	int arr[3][5];
	
	cout << "Enter Values for 3 x 5 Array: ";
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 5; j++)
		{
			cin >> arr[i][j];	
		}	
	}	
	cout << "Values of 3 x 5 Array after addition of 10 are: " << endl;
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 5; j++)
		{
			cout <<  arr[i][j] + 10 << " ";	
		}	
		cout << endl;
	}
}
	
