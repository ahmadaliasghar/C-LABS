#include<iostream>
using namespace std;
int main()
{
	char arr[20];
	int sum = 0;
	
	cout << "Enter your name: ";
	gets(arr);
	
    for(int i = 0; arr[i] != 0; i++)
	{
        sum = sum + 1;
    }
	
    for(int i = sum ; i >= 0; i--)
	{
        cout << arr[i];
    }
}
