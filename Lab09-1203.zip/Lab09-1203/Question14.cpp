#include <iostream>
#include<cstring>

using namespace std;
void palindrome(char string1[20], char string2[20]){
	int i, length1, length2;
    int flag1 = 0, flag2 = 0;
 
//    *******String 2 Palindrome*******
    length1 = strlen(string1);
    for(i=0;i < length1;i++){
        if(string1[i] != string1[length1-i-1]){
            flag1 = 1;
            break;
           }
        }
    
    if (flag1) {
        cout << string1 << " is not a palindrome" << endl; 
    }    
    else {
        cout << string1 << " is a palindrome" << endl; 
    }
//    *******String 2 Palindrome*******
    length2 = strlen(string2);
    for(i=0;i < length2 ;i++){
        if(string2[i] != string2[length2-i-1]){
            flag2 = 1;
            break;
           }
        }
    
    if (flag2) {
        cout << string2 << " is not a palindrome" << endl; 
    }    
    else {
        cout << string2 << " is a palindrome" << endl; 
    }
}
int main(){
    char string1[20], string2[20];
    cout<<"Enter first string in small alphabets: ";
    gets(string1);
    cout<<"Enter second string in small alphabets: ";
    gets(string2);
    palindrome(string1, string2);
    return 0;
}
