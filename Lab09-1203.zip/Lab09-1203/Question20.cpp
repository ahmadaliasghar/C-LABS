#include <iostream>
using namespace std;

int main()
{
	int arr[4][4];
	int arr1[4][4];
	int subtract[4][4] = {};
	
	
	cout << "Enter 16 Values for 4 x 4 Array 1: ";
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			cin >> arr[i][j];
		}
	}
	
	cout << "Enter 16 Values for 4 x 4 Array 2: ";
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			cin >> arr1[i][j];
		}
	}
	
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			subtract[i][j] = arr1[i][j] - arr[i][j];
		}
	}
	
	cout << "\nAfter subtraction Matrix 1 from Matrix 2 , Values are: " << endl;
	
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			cout << subtract[i][j] << " ";
		}
		cout << endl;
	}
	
	
}
