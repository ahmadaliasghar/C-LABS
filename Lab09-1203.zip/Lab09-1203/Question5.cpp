#include<iostream>
using namespace std;
int main()
{
	char arr[100];
	int count = 0;
	
	cout << "Enter a string: ";
	gets(arr);
	
	for(int i = 0; arr[i] != 0; i++)
	{
		cout << arr[i];
		if(arr[i] != ' ')
		{
			count = count + 1;
		}
	}
	
	cout << "\n\nTotal alphabets in the entered string are: " << count << endl;
}
