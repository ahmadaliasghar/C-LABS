#include<iostream>
using namespace std;
int main()
{
	int count = 0;
	char arr[] = "The most likely way for the world to be destroyed,\n\tMost experts agree,'is by accident'.\n\t\tThat where we come in;\nWe are computer professionals.We cause accidents'.";

	for(int i = 0; arr[i] != 0; i++)
	{
		cout << arr[i];
	}
		
	for(int i = 0; arr[i] != 0; i++)
	{
		if(arr[i]=='a' || arr[i]=='e'|| arr[i]=='i' || arr[i]=='o' || arr[i]=='u')
		{
			count = count + 1;
		}
	}

	cout << "\n\nTotal vowels in the above string are: " << count << endl;
}
