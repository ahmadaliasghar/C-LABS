#include <iostream>
using namespace std;
int main()
{

int arr[3][2] = {{1, 2}, {3, 4}, {5, 6}};

cout << "Before Swapping: " << endl;

cout << arr[0][0] << " ";
cout << arr[0][1] << "\n";
cout << arr[1][0] << " ";
cout << arr[1][1] << "\n";
cout << arr[2][0] << " ";
cout << arr[2][1] << "\n";

cout << "\\nAfter Swapping: " << endl;

cout << arr[0][0] << " ";
cout << arr[2][1] << "\n";
cout << arr[1][0] << " ";
cout << arr[1][1] << "\n";
cout << arr[2][0] << " ";
cout << arr[0][1] << "\n";

	
}
