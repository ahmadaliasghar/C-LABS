#include<iostream>
using namespace std;
int main()
{
    char arr[20];
    char arr1[20];

    cout << "Enter your first name: ";
    gets(arr);
    
    cout<<"Enter your second name: ";
    gets(arr1);

    cout << endl;

    cout << arr << " " << arr1 << endl;
    
}
