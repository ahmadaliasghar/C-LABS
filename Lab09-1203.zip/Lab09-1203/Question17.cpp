#include <iostream>
using namespace std;

int main()
{
	int arr[5][5];
	
	cout << "Enter Values for 5 x 5 Array: ";
	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j < 5; j++)
		{
			cin >> arr[i][j];	
		}	
	}	
	cout << "Values of 5 x 5 Array are: " << endl;
	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j < 5; j++)
		{
			cout  << arr[i][j] << " ";	
		}	
		cout << endl;
	}	
}
