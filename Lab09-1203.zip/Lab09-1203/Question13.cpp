#include<iostream>
using namespace std;
float average(float a, float b, float c){
	float avg;
	return (a+b+c)/3;
}
int main(){
	float array[20]={1,2.3,3,4.5,6,7,8,9,10,13.56,14.87,23.98,13.4,14.8,15.67,16.90,18.99,17.54,20.43,19.33};
	float a=array[0], b=array[9], c=array[19];
	cout<<"Average is: "<<average(a,b,c);
	return 0;
}
