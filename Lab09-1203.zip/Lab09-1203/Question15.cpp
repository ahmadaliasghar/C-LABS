#include <iostream>
using namespace std;
int main()
{
	int arr[3][5] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
	
	cout << arr[0][0] << " ";
	cout << arr[0][1] << " ";
	cout << arr[0][2] << " ";
	cout << arr[0][3] << " ";
	cout << arr[0][4] << "\n";
	cout << arr[1][0] << " ";
	cout << arr[1][1] << " ";
	cout << arr[1][2] << " ";
	cout << arr[1][3] << " ";
	cout << arr[1][4] << "\n";
	cout << arr[2][0] << " ";
	cout << arr[2][1] << " ";
	cout << arr[2][2] << " ";
	cout << arr[2][3] << " ";
	cout << arr[2][4] << "\n";
	
}
