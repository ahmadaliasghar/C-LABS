#include <iostream>
using namespace std;
int main()
{	

	for(int i = 1; i <= 5; i++)
	{
		for(int m = 5; m > i; m--)
		{
			cout << " ";
		}
		for(int a = 1; a <= i; ++a)
		{
			cout << "*";
		}
		
		cout << "\n\n";
	}

	
	return 0;
}
