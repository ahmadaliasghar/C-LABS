#include <iostream>
using namespace std;

void encrypt();
void decrypt();

int main()
{
	encrypt();
	decrypt();
}

void encrypt()
{
	int num, num1, num2, num3, num4;
	
	
	do{
		cout << "Encrypt the four digit Number: ";
		cin >> num;
		
		if(num>9999||num<1000)
		{
			cout << "Invalid Number!!!, Kindly Enter a four digit Number" << endl;
		}
		else 
			break;
		}
		
		
	while(1);
	{
		num4 = num % 10;
		num = num / 10;
		
		num3 = num % 10;
		num = num / 10;
		
		num2 = num % 10;
		num = num / 10;
		
		num1 = num % 10;
		num = num / 10;
	}
		cout << "The encrypted four digit Number is: " << num3 << num4 << num1 <<num2;
}

void decrypt()
{
	
	int num, num1, num2, num3, num4;
	
	do{
		cout << "\nDecrypt the four digit Number: ";
		cin >> num;
		
		if(num>9999||num<1000)
		{
			cout << "Invalid Number!!!\t Enter a four digit Number" << endl;
		}
		else 
			break;
		}
	while(1);
	{
	
		num4 = num % 10;
		num = num / 10;
		
		num3 = num % 10;
		num = num / 10;
		
		num2 = num % 10;
		num = num / 10;
		
		num1 = num % 10;
		num = num / 10;
	}
		cout << "The decrypted four digit Number is: " << num3 << num4 << num1 <<num2;
}

