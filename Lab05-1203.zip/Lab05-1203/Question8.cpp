#include <iostream>
using namespace std;
int main()
{
	int n1, n2, n3, n4, n5;
	
	cout << "Enter 5 Numbers: ";
	cin >> n1 >> n2 >> n3 >> n4 >> n5;
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= n1; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= n2; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= n3; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= n4; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= n5; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	return 0;
}
