#include <iostream>
using namespace std;

int cal();

int main()
{
	cal();
}

int cal()
{
	int n1, n2, n3, n4, n5;
	float average;
	
	cout << "Enter marks: ";
	cin >> n1 >> n2 >> n3 >> n4 >> n5;
	
	average = (n1 + n2 + n3 + n4 + n5) / 5;
	
	cout << "\nAverage = " << average;

}
