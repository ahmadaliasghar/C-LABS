#include <iostream>
using namespace std;
int main()
{
	int x, reverse=0, rem;
	cout << "Enter the number: ";
	cin >> x;
	
	do
	{
		rem = x % 10;
		reverse = reverse * 10 + rem;
		x = x / 10;	
	}
	
	while(x!=0);
		cout << "The reverse of given Number is: " << reverse << endl;
	
	 return 0;
}
