#include <iostream>
using namespace std;
int main()
{
	
	int num;
	int first = 0;
	int second = 1;
	int next;
	
	cout << "Enter the boundary to be printed in the fibonacci series: " << endl;
	cin >> num;
	
	cout << "Fibonacci Serires: "<< first << " " << second;
	
	do
	{
		next = first + second;
		if(next > num)
			{
				break;
			}
		cout << " " << next;
		first = second;
		second = next;
		
	}
	while(1);
	
	return 0;
	
}
