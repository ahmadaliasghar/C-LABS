#include <iostream>
using namespace std;
int main()
{
	int num;
	int max;
	int min;
	int i = 1;
	
	max = 0;
	min = 99999;
	
	do
	{
		cout << " Enter any Number: ";
		cin >> num;
		
		if(num>max)
			max = num;
			
		if(num<min)
			min = num;
		
		i++;
	}
	while(i<=10); 
	{
		cout << "\nThe Maximum Number is: " << max;
		cout << "\nThe Minimum Number is: " << min;
	}
	
	return 0;
	
}
