#include <iostream>
using namespace std;
int main()
{
	int marks, num, sum;
	float average;
	
	
	do
	{
		cout << "Input marks of student: ";
		cin >> marks;
		
		sum = sum + marks;
		num++;
		
		average = sum / 10;
		
	}
	  
	while(num<10);
	{
		cout << "The sum is: " << sum << endl;
		cout << "The average is: " << average << endl;
	}
	
	
	
	return 0;
}
