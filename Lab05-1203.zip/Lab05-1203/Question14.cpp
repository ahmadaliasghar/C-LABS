#include <iostream>
using namespace std;

void evenOdd();

int main()
{
	evenOdd();
}

void evenOdd()
{
	int num;
	cout << "Enter a Number: ";
	cin >> num;
	
	if(num%2==0)
	{
		cout << "\n\t"<< num << " is a Even Number." << endl;
	}
	
	if(num%2!=0)
	{
		cout << "\n\t" << num << " is a Odd Number." << endl;
	}
}
