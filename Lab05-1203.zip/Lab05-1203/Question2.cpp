#include <iostream>
using namespace std;
int main()
{
	int num = 1;
	char gender;
	
	int males = 0;
	int females = 0;
	
	
	do
	{
		cout << "Enter (M,m) for Male & (F,f) for Female: ";
		cin >> gender;
	
		if(gender=='M'||gender=='m')
			males++;
		
		if(gender=='F'||gender=='f')
			females++;	
			
		num++;
	}
	
	while(num<=10);
	{
		num++;
	}
	
	cout << " \nNumber of Males are: " << males << endl;
	cout << "Number of Females are: " << females << endl;
	
	return 0;
	
}
