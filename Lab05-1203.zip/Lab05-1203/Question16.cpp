#include <iostream>
using namespace std;

void star();

int main()
{
	star();
	star();
	star();
	star();
	star();
}

void star()
{
	for(int a = 1; a <= 10; a++)
	{
		for(int m = 1; m <= a; m++)
		{
			cout << "*";
		}
		cout << "\n";
		
	}
	
}
