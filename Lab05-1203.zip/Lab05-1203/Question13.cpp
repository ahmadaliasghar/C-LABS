#include <iostream>
using namespace std;

void display();

int main()
{
	display();
}

void display()
{
	for(int i = 1; i <= 10; i++)
	{
		for(int a = 1; a <= 2*i-1; a++)
		{
			cout << "#";
		}
		cout << "\n";
	}
}
