#include <iostream>
using namespace std;
int main()
{
	for(int j = 1; j <= 5; j++)
	{
		for(int a = 1; a <= j; a++)
		{
			cout << "*";
		}
		cout << "\n\n";
	}
}
