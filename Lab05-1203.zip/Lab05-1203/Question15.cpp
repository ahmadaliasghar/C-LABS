#include <iostream>
using namespace std;

void TenSpace();

int main()
{
	TenSpace();
}

void TenSpace()
{
	cout << "First";
	for(int i = 1; i <= 10; i++)
	{
		cout << " ";
	}
	cout << "Last";
}
