#include <iostream>
using namespace std;

void sign1();
void sign2();
void sign3();


int main()
{
	sign1();
	cout << "\n";
	sign2();
	cout << "\n";
	sign3();
	cout << "\n";
}

void sign1(){
	for(int i = 0; i <= 20; i++)
	cout << "*";
}

void sign2(){
	for(int i = 0; i <= 20; i++)
	cout << "$";
}


void sign3(){
	for(int i = 0; i <= 20; i++)
	cout << "@";
}


