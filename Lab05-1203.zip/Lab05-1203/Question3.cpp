#include <iostream>
using namespace std;
int main()
{
	char option;
	float num1, num2;
	int count;
	
	do
	{
		
	cout << "Enter first Number:  ";
	cin >> num1;
	
	cout << "Enter second Number:  ";
	cin >> num2;
	
	cout << "Enter operand:  ";
	cin >> option;
	
	if(option=='+')
		cout << "The addition of " << num1 << " and " << num2 << " is : " << num1 + num2 << endl;
		
	
	if(option=='-')
		cout << "The subtraction of " << num1 << " and " << num2 << " is : " << num1 - num2 << endl;
		
	
	if(option=='*')
		cout << "The multiplication of " << num1 << " and " << num2 << " is : " << num1 * num2 << endl;
		
	
	if(option=='/')
		cout << "The division of " << num1 << " and " << num2 << " is : " << num1 / num2 << endl;	
		
	
	}while(option!='e');
		cout << "\nOpertaion Exited";
	
	
	return 0;
}
