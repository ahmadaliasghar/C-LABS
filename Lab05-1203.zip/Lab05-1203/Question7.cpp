#include <iostream>
using namespace std;
int main()
{
	for(int i = 1; i <= 5; i++)
	{
		for(int a = 1; a <= i; a++)
		{
			cout << "*" ;
		}
		
		cout << "\n\n";
	}
	
	cout << endl;
	
	for(int i = 5; i >= 1; i--)
	{
		for(int a = 1; a <= i; a++)
		{
			cout << "*";
		}
		
		cout << "\n\n";
	}
	
	cout << endl;

	for(int i = 5; i >= 0; i--)
	{
		for(int a = 1; a <= i; a++)
		{
			cout << "*";
		}
		
		cout << "\n\n";
	}
	
	
	for(int i = 1; i <= 5; i++)
	{
		for(int m = 5; m > i; m--)
		{
			cout << " ";
		}
		for(int a = 1; a <= i; ++a)
		{
			cout << "*";
		}
		
		cout << "\n\n";
	}
	
	return 0;
	
}
