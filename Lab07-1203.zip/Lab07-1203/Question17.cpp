#include <iostream>
#include <cmath>

using namespace std;
template <class T>
T xcos(T A , T xc = 3, T r = 7)
{
	T x;
	T rad;
	rad = (A * 3.1416) / 180;
	x = xc + (r * cos(rad));
	
	cout << "Value of 'x' for theta " << A << " is: " << x << endl;
}

template <class M>
M ysin(M A , M yc = 3, M r = 7)
{
	M y;
	M rad;
	rad = (A * 3.1416) / 180;
	y = yc + (r * sin(rad));
	
	cout << "Value of 'y' for theta " << A << " is: " << y << endl;
}

int main()
{
	// For 90 degrees
	xcos(90);
	ysin(90);
	//For 120 degrees
	xcos(120);
	ysin(120);
}


