#include <iostream>
using namespace std;

int input(int &num, int &num1, int &num2)
{
	cout << "Input three int values: ";
	cin >> num >> num1 >> num2;
}
char input(char &num, char &num1, char &num2)
{
	cout << "Input three char values: ";
	cin >> num >> num1 >> num2;
}
float input(float &num, float &num1, float &num2)
{
	cout << "Input three float values: ";
	cin >> num >> num1 >> num2;
}

