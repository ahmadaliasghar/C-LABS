#include<iostream>
#include<cmath>
using namespace std;

template <class T>
T form(T x, T yc = 3, T xc = 3, T r = 7)
{
	T y1, y2;
	
	y1 = yc + sqrt(pow(r, 2) - pow((xc - x),2));
	y2 = yc - sqrt(pow(r, 2) - pow((xc - x),2));

	cout << "The value of y is: " << y1 << ", " << y2 << endl;
}
int main()
{
	form(10);
	form(11);
	form(12);
	form(13);
	form(14);
	form(15);
	
	return 0;
}
	
