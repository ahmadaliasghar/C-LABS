#include <iostream>
using namespace std;

int add(int num1, int num2)
{
	return num1 + num2;
}

float add(float num1, float num2)
{
	return num1 + num2;
}

int add(int num1, int num2, int num3)
{
	return num1 + num2 + num3;
}


float add(float num1, float num2, float num3)
{
	return num1 + num2 + num3;
}

int main()
{
	// Two Integers Values
	int n1, n2;
	cout << "Enter two integer value: ";
	cin >> n1 >> n2;
	cout << "The sum of two integer values is: " << add(n1, n2) << endl;
	
	//Two Float Values
	float nu1, nu2;
	cout << "\nEnter two float value: ";
	cin >> nu1 >> nu2;
	cout << "The sum of two float values is: " << add(nu1, nu2) << endl;
	
	//Three Integers Values
	int num1, num2, num3;
	cout << "\nEnter three integer value: ";
	cin >> num1 >> num2 >> num3;
	cout << "The sum of three integer values is: " << add(num1, num2, num3) << endl;
	
	//Three Float Values
	float numb1, numb2, numb3;
	cout << "\nEnter three float value: ";
	cin >> numb1 >> numb2 >> numb3;
	cout << "The sum of three float values is: " << add(numb1, numb2, numb3) << endl;
}
