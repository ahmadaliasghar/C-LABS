#include <iostream>
using namespace std;

template<class T>
T average(T num1, T num2, T num3, T num4, T num5)
{
	cout << "The average is: " << (num1 + num2 + num3 + num4 + num5) / 5 << endl;
	 
}

int main()
{
	int n1, n2, n3, n4, n5;
	
	cout << "Enter first number: ";
	cin >> n1;
	
	cout << "Enter second number: ";
	cin >> n2;
	
	cout << "Enter third number: ";
	cin >> n3;
	
	cout << "Enter fourth number: ";
	cin >> n4;
	
	cout << "Enter fifith number: ";
	cin >> n5;
	
	average(n1, n2, n3, n4, n5);
	
	return 0;
}
