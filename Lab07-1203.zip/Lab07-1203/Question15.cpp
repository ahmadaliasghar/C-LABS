#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int num1, num2;
	char option;
	cout << "Enter 'p' to calculate power" << endl; 
	cout << "Enter 's' to calculate sin" << endl; 
	cout << "Enter 'r' to calculate squareroot" << endl; 
	cout << "Enter 't' to calculate tan" << endl; 
	cout << "Enter option: ";
	cin >> option;
	
	switch(option)
	{
		case 'p':
			{
				cout << "\nEnter first number: ";
				cin >> num1;
				cout << "Enter second number: ";
				cin >> num2;
				
				cout << "\nPower of " << num1 << " raise " << num2 << "= " << pow(num1, num2) << endl;
				break;
			}
		case 's':
			{
			cout << "Enter the number: ";
			cin >> num1;
			double rad = (num1 * 3.14159)/180;
			cout << "\nThe sin(" << num1 << ") is: "<<sin(rad)<<endl;
			break;
			}
		case 'r':
			{
			cout << "Enter the number: ";
			cin >> num1;
			cout << "\nThe squareroot of " << num1 << " is: " << sqrt(num1) << endl;
			break;
			}
		case 't':
			{
			cout << "Enter the number: ";
			cin >> num1;
			double rad = (num1 * 3.14159)/180;
			cout << "\nThe tan(" << num1 << ") is: " << tan(rad) << endl;
			break;
			}
	}
	
	return 0;
}
