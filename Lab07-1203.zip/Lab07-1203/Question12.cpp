#include <iostream>
#include"Header1.h"
using namespace std;

int main()
{
	cout << "Add:\t" << add(10, 20) << endl;
	cout << "Subtract:\t" << subtract(50, 30) << endl;
	cout << "Multiply:\t" << multiply(10, 20) << endl;
	return 0;
}


