#include<iostream>
using namespace std;

void swap(int &a, int &b)
{
	cout << "Values Before Swaping : " << a << endl;
	cout << "Values Before Swaping : " << b << endl;

	int temp;
	temp = a;
	a = b;
	b = temp;
	
	cout << "Values After Swaping : " << a << endl;
	cout << "Values After Swaping : " << b << endl;
	
}

void swap(char &a, char &b)
{
	cout << "Values Before Swaping : " << a << endl;
	cout << "Values Before Swaping : " << b << endl;
	
	char temp;
	temp = a;
	a = b;
	b = temp;
	
	cout << "Values After Swaping : " << a << endl;
	cout << "Values After Swaping : " << b << endl;

}

int main ()
{
	int x, y;
	
	cout << "Enter two integers values: ";
	cin >> x >> y;
	
	swap(x, y); 
	
	char fir, sec;
	
	cout << "\nEnter two char values: ";
	cin >> fir >> sec;
	
	swap(fir, sec);
	
	 return 0;
}
