#include <iostream>
#include "Input.h"
#include "Output.h"

using namespace std;

int main()
{
	int x, y, z;
	char a, b, c;
	float j, k , l;
	
	input(x, y, z);
	output(x, y, z);

	input(a, b, c);
	output(a, b, c);

	input(j, k, l);
	output(j, k, l);
	
	return 0;
}
