#include <iostream>
using namespace std;

int output(int &num, int &num1, int &num2)
{
	cout << "Three int values are: " << num << " " << num1 << " "<< num2 << endl;

}
char output(char &num, char &num1, char &num2)
{
cout << "Three char values are: " << num << " " << num1 << " "<< num2 << endl;
}
float output(float &num, float &num1, float &num2)
{
	cout << "Three float values are: " << num << " " << num1 << " "<< num2 << endl;
}

