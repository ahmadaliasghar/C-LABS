#include <iostream>
using namespace std;

float average(float num1, float num2, float num3, float num4, float num5 = 0)
{
	float average = (num1 + num2 + num3 + num4 + num5) / 5;
	
	return average;
}

int main()
{
	float n1, n2, n3 , n4, n5;
	
	cout << "Enter 5 Numbers: ";
	cin >> n1 >> n2 >> n3 >> n4 >> n5;
		
	cout << "The average of given numbers is: " << average(n1, n2, n3, n4, n5) << endl;
}
