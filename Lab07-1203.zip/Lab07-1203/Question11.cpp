#include <iostream>
using namespace std;

template <class T>
T swapping(T fir, T sec)
{
	T temp;
	
	cout << "Before Swapping First Value : " << fir << endl;
	cout << "Before Swapping Second Value : " << sec << endl;
	
	
	temp = fir;
	fir = sec;
	sec = temp;
	
	cout << "\nAfter Swapping First Value : " << fir << endl;
	cout << "After Swapping Second Value : " << sec << endl;
	
}
int main()
{
	int num1 , num2;
	
	cout << "Enter first integer value : ";
	cin >> num1;
	
	cout << "Enter second integer value : ";
	cin >> num2;
	
	swapping(num1, num2);
	
	char first , second;
	
	cout << "\nEnter first character value : ";
	cin >> first;
	
	cout << "Enter second character value : ";
	cin >> second;
	
	swapping(first, second);
}
