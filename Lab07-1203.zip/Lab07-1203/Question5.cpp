#include <iostream>
using namespace std;

int input(int &num, int &num1, int &num2)
{
	cout << "Input three int values: ";
	cin >> num >> num1 >> num2;
}
char input(char &num, char &num1, char &num2)
{
	cout << "Input three char values: ";
	cin >> num >> num1 >> num2;
}
float input(float &num, float &num1, float &num2)
{
	cout << "Input three float values: ";
	cin >> num >> num1 >> num2;
}

int output(int &num, int &num1, int &num2)
{
	cout << "Three int values are: " << num << " " << num1 << " "<< num2 << endl;

}
char output(char &num, char &num1, char &num2)
{
cout << "Three char values are: " << num << " " << num1 << " "<< num2 << endl;
}
float output(float &num, float &num1, float &num2)
{
	cout << "Three float values are: " << num << " " << num1 << " "<< num2 << endl;
}

int main()
{
	int x, y, z;
	char a, b, c;
	float j, k , l;
	
	input(x, y, z);
	output(x, y, z);

	input(a, b, c);
	output(a, b, c);

	input(j, k, l);
	output(j, k, l);
	
}
