#include <iostream>
using namespace std;

template <class T>
T small(T num1, T num2, T num3)
{
	T min;
	if((num1<num2)&&(num1<num3))
		min = num1;
	else if(num2<num3)
		min = num2;
	else
		min = num3;
		
	cout << "\nThe smallest value is: " << min << endl;
	
}

int main()
{
	int n1, n2, n3;
	
	cout << "Enter first number: ";
	cin >> n1;
	
	cout << "Enter second number: ";
	cin >> n2;
	
	cout << "Enter third number: ";
	cin >> n3;
	
	small<int>(n1, n2, n3);
	
	cout << endl;
	
	float x, y, z;
	cout << "Enter the first decimal point number  : ";
	cin >> x;
	cout << "Enter the second decimal point number : ";
	cin >> y;
	cout << "Enter the third decimal point number  : ";
	cin >> z;
	cout << endl;
	small<float>(x, y, z);
	
	cout << endl;
	
	char fir, sec, thir;
	cout << "Enter the first character  : ";
	cin >> fir;
	cout << "Enter the second character : ";
	cin >> sec;
	cout << "Enter the third character  : ";
	cin >> thir;
	cout << endl;
	small<char>(fir, sec, thir);
	return 0;
}

