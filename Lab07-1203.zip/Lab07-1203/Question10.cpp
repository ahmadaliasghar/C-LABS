#include <iostream>
using namespace std;

template <class T>
T area(T radius)
{
	T pie = 3.1416;
	
	T area;
	
	area = pie * radius * radius;
	
	cout << "The area the circle is: " << area << endl;
}

int main()
{
	float rad;
	
	cout << "Enter radius of the circle to calculate area of the circle: ";
	cin >> rad;
	
	area(rad);
	
	return 0;
}
