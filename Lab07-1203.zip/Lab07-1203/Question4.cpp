#include <iostream>
using namespace std;

int largest(int num1, int num2, int num3)
{
	int max = 0;
	
	if(num1>max)
		max = num1;
	if(num2>max)
		max = num2;
	if(num3>max)
		max = num3;
	
}

float largest(float num1, float num2, float num3)
{
	float max = 0;
	
	if(num1>max)
		max = num1;
	if(num2>max)
		max = num2;
	if(num3>max)
		max = num3;
	
}
int main()
{
	int n1, n2, n3;
	cout << "Enter three integers values: ";
	cin >> n1 >> n2 >> n3;
	cout << "The largest integer number is: " << largest(n1, n2, n3) << endl;
	
	
	float nu1, nu2, nu3;
	cout << "\nEnter three float values: ";
	cin >> nu1 >> nu2 >> nu3;
	cout << "The largest float  number is: " << largest(nu1, nu2, nu3) << endl;
}



