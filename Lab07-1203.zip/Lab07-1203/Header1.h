#include <iostream>
using namespace std;
float add(float num1, float num2, float num3 = 0, float num4 = 0, float num5 = 0)
{
	float add = num1 + num2 + num3 + num4 + num5;
	
	return add; 
}
float subtract(float num1, float num2, float num3 = 0, float num4 = 0, float num5 = 0)
{
	float subtract = num1 - num2 - num3 - num4 - num5;
	
	return subtract; 
}
float multiply(float num1, float num2, float num3 = 1, float num4 = 1, float num5 = 1)
{
	float multiply = num1 * num2 * num3 * num4 * num5;
	
	return multiply; 
}
