#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	double num1, num2;
	cout << "Enter the first number  : ";
	cin >> num1;
	cout << "Enter the second number : ";
	cin >> num2;
	double rad = (num1 * 3.14159) / 180;

	cout << "\nWith Variables: " << endl;
	cout << "pow(" << num1 << "," << num2 << ")      " << pow(num1, num2) << endl;
	cout << "sin(" << num1 << ")        " << sin(rad) << endl;
	cout << "sqrt(" << num1 << ")       " << sqrt(num1) << endl;
	cout << "tan(" << num1 << ")        " << tan(rad) << endl;
	cout << endl;

	cout << "\nWith Constants: " << endl;
	cout << "pow(" << 5 << "," << 7 << ")      " << pow(5, 7) << endl;
	cout << "sin(" << 5 << ")        " << sin(5) << endl;
	cout << "sqrt(" << 5 << ")       " << sqrt(5) << endl;
	cout << "tan(" << 5 << ")        " << tan(5) << endl;

	return 0;
}
