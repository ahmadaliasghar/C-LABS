#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

int main(){
	
	char *ptr = new char[1], *ptr1 = new char[1];
	
	int var = 5;
	
	cout<<"Enter a string (at least 5 sentences): ";
	gets(ptr);
	
	ptr1 = strtok(ptr, ".");
	
	
	while(ptr1 != NULL)
	{
		int i = 1;
		cout << i << "Sentence is : " << ptr1 << endl;

		ptr1 = strtok(NULL, ".");
		
		i++;
	}
	
	return 0;	
	
}
