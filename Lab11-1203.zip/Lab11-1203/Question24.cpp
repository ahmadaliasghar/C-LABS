#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;

int main()
{
	char *ptr = new char[1], *ptr1 = new char[1];
	
	int var = 5;
	
	cout << "Enter a string: ";
	gets(ptr);
	
	strncpy(ptr1, ptr, var);
	
	cout << "\n--------------------------\n";
	
	cout << ptr1;
	
	return 0;
	 
}
