#include <iostream>
using namespace std;

void print(int *ptr)
{
	for(int i = 0; i < *ptr; i++)
	{
		cout << "*";
	}
}
int main()
{
	int num;
	
	cout  << "Enter the number: ";
	cin >> num;
	
	print(&num);
	
	
}
