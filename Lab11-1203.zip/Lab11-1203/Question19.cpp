#include<iostream>
using namespace std;
void maxi(int*, int*, int*, int*, int*);

int main()
{
	int *ptr1, *ptr2, *ptr3, *ptr4, *ptr5;
	
	ptr1 = new int;
	ptr2 = new int;
	ptr3 = new int;
	ptr4 = new int;
	ptr5 = new int;
	
	cout << "Enter value to 1st pointer: ";
	cin >> *ptr1;
	
	cout << "Enter value to 2nd pointer: ";
	cin >> *ptr2;
	
	cout << "Enter value to 3rd pointer: ";
	cin >> *ptr3;
	
	cout << "Enter value to 4th pointer: ";
	cin >> *ptr4;
	
	cout << "Enter value to 5th pointer: ";
	cin >> *ptr5;
	
	cout << "\n\n";
	
	maxi(ptr1, ptr2, ptr3, ptr4, ptr5);
	
}
void maxi(int *one, int *two, int *three, int *four, int *five)
{
	int max = *one;
	
	if(*one > max)
	{
		max = *one;
	}
	
	if(*two > max)
	{
		max = *two;
	}
	
	if(*three > max)
	{
		max = *three;
	}
	
	if(*four > max)
	{
		max = *four;
	}
	
	if(*five > max)
	{
		max = *five;
	}
	
	cout << "The largest element is: " << max << endl;
}
