#include <iostream>
using namespace std;

int main()
{
	int arr[5];
	
	
	for(int i = 0; i < 5; i++)
	{
		cout << "Enter 5 double values: ";
		cin >> arr[i];
	}
	
	int *ptr;
	
	ptr = arr;
	
	cout << "The 1st value is: " << *ptr << endl; 
	cout << "The 2nd value is: " << *(ptr + 1) << endl; 
	cout << "The 3rd value is: " << *(ptr + 2) << endl; 
	cout << "The 4th value is: " << *(ptr + 3) << endl; 
	cout << "The 5th value is: " << *(ptr + 4) << endl; 

	
}
