#include<iostream>
using namespace std;
int main()
{
	char *ptr1, *ptr2, *ptr3;
	
	ptr1 = new char;
	ptr2 = new char;
	ptr3 = new char;
	
	*ptr1 = 'A';
	*ptr2 = 'B';
	*ptr3 = 'C';
	
	cout << "The 3 pointers are: " << *ptr1 << " " <<  *ptr2 << " " << *ptr3 << endl;
	
	delete ptr1;
	delete ptr2;
	delete ptr3;
}
