#include<iostream>
using namespace std;
int main()
{
	int arr[10];
	
	for(int i = 0; i < 10; i++)
	{
		cout << "Enter 10 numbers: ";
		cin >> arr[i];
	}
	
	int *ptr;
	
	ptr = arr;
	
	cout << "The 3rd value pointer pointing to is: " << *(ptr + 2) << endl;
	cout << "The 5th value pointer pointing to is: " << *(ptr + 4) << endl;
	cout << "The 9th value pointer pointing to is: " << *(ptr + 8) << endl;
}
