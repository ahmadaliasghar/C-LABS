#include <iostream>
using namespace std;

void print(int *ptr1, int *ptr2, int *ptr3, int *ptr4, int *ptr5)
{
	for(int i = 0; i < *ptr1; i++)
	{
		cout << "#";
	}
	cout << endl;
	for(int i = 0; i < *ptr2; i++)
	{
		cout << "#";
	}
	cout << endl;
	for(int i = 0; i < *ptr3; i++)
	{
		cout << "#";
	}
	cout << endl;
	for(int i = 0; i < *ptr4; i++)
	{
		cout << "#";
	}
	cout << endl;
	for(int i = 0; i < *ptr5; i++)
	{
		cout << "#";
	}
}

int main()
{
	int num1, num2, num3, num4, num5;
	
	
	cout << "Enter 5 numbers between 1 - 20: ";
	cin >> num1 >> num2 >> num3 >> num4 >> num5;
	
	
	
	print(&num1, &num2, &num3, &num4, &num5);
	
}
