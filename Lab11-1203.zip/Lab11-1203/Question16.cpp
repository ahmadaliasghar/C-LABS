#include<iostream>
using namespace std;
void input(int*);
void output(int*);

int main()
{
	int arr[10];
	input(arr);
	cout << endl;
	output(arr);
}
void input(int *one)
{
	for(int i = 0; i < 10; i++)
	{
		cout << "Enter 10 Elements: ";
		cin >> *(one + i);
	}
}
void output(int *two)
{
	cout << "The 10 Elements are: ";

	for(int i = 0; i < 10; i++)
	{
		cout <<  *(two + i) << " ";
	}
}
