#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

int main()
{
	char *ptr = new char[1], *ptr1 = new char[1];
	char *ptr2 = "of";
		
	int count = 0;
	
	cout << "Enter a string: ";
	gets(ptr);
	
	ptr1 = strtok(ptr, " ");
	
	while(ptr1 != '\0')
	{
		if(strcmp(ptr2, ptr1) == 0)
			count++;
		ptr1 = strtok(NULL," ");
	}
	
	cout << endl;
	
	cout << ptr2 << " is found " << count <<" times." << endl;
	
	return 0;	
}
