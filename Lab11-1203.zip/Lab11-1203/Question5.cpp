#include<iostream>
using namespace std;


int fact(int *ptr)
{
	cout << "\n\nThe factorial of " << *ptr << " is :\t";
	int result = 1;
	for(int i = 1; i <= *ptr; i++)
	{
		cout << i << "!";
		result = result * i;
	}
	cout << " =\t";
	
	return result;
}
int main()
{
	int *ptrFactorial;
	int one;
	
	ptrFactorial = &one;
	cout << "Enter the number where you want caculate factorial:\t";
	cin >> *ptrFactorial;
	
	cout << fact(ptrFactorial);
	return 0;
}

