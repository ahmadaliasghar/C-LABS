#include <iostream>
using namespace std;

int main()
{
	float *ptr1;
	float *ptr2;
	
	float var;
	
	ptr1 = &var;
	
	ptr2 = ptr1;
	
	*ptr2 = 3.5;
	
	cout << "The value is: " << *ptr1 << endl;
}
