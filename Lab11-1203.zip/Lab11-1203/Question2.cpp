#include<iostream>
using namespace std;

void print(int *ptr, char *alpha)
{
	for(int i = 0; i < *ptr; i++)
	{
		for(int j = 0; j < *ptr; j++)
		{
			cout << *alpha;
		}
		cout << endl;
	}
}
int main()
{
	int num;
	char var;
	
	cout << "Enter the lenght for rectangle: ";
	cin >> num;
	
	cout << "Enter the character for rectangle: ";
	cin >> var;
	
	cout << endl;
	
	print(&num, &var);
	
}
