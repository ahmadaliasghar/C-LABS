#include <iostream>
using namespace std;

int main()
{
	int *ptr;
	
	int var;
	
	ptr = &var;
	
	cout << "The previous address of variable is: " << ptr-1 << endl;
	cout << "The current address of variable is: " << ptr << endl;
	cout << "The next address of variable is: " << ptr+1 << endl;

}
