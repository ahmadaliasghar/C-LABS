#include<iostream>
using namespace std;
int main()
{
	int size = 0;
	
	char arr[20] = "This is a text code";
	char *ptr;
	
	ptr = arr;
	
	for(int i = 0; arr[i] != '\0'; i++, size++);
	
		for(int i = size; i > 0; i--)
		{
			cout << *(ptr + (i - 1));
		}
	
}
