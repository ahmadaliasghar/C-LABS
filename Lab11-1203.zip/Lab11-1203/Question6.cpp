#include <iostream>
using namespace std;

const float PI = 3.14;

float inputRadius(float *radius)
{
	
	cout << "Enter the value of radius:\t";
	cin >> *radius;
}
void areaOfCircle (float *radius)
{
	float area;
	area = PI * (*radius) *(*radius);
	cout << "The area is: " << area << endl;
}

int main()
{
	float radius;
	
	inputRadius(&radius);
	areaOfCircle(&radius);
	

	return 0;	
}

