#include<iostream>
using namespace std;

float average(int *ptr1, int *ptr2, int *ptr3, int *ptr4, int *ptr5)
{
	int sum = 0;
	
	sum = *ptr1 + *ptr2 + *ptr3 + *ptr4 + *ptr5;
	
	return sum / 5;
}
int main()
{
	int num1, num2, num3, num4, num5;
	
	cout << "Enter your marks: ";
	cin >> num1 >> num2 >> num3 >> num4 >> num5;
	
	cout << "Average is: " << average(&num1, &num2, &num3, &num4, &num5);
}
