#include<iostream>
using namespace std;
int main()
{
	int var, *ptr, **ptr1;
	
	var = 10;
	ptr = &var;
	ptr1 = &ptr;
	**ptr1 = **ptr1 + 50;
	
	cout << **ptr1 << endl;
}
