#include<iostream>
using namespace std;
int main()
{
	int *ptr1, *ptr2, *ptr3;
	
	ptr1 = new int;
	ptr2 = new int;
	ptr3 = new int;
	
	*ptr1 = 10;
	*ptr2 = 20;
	*ptr3 = 30;
	
	cout << "The addition of 3 pointers is: " << *ptr1 + *ptr2 + *ptr3 << endl;
	
	delete ptr1;
	delete ptr2;
	delete ptr3;
}
