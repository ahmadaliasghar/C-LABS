#include<iostream>
using namespace std;

void swap1(int*, int*);

int main()
{
	int arr1[5], arr2[5];
	
	for(int i = 0; i < 5; i++)
	{
		cout << "Enter 5 elements for the first array: ";
		cin >> arr1[i];
	}
	cout << endl << endl;
	for(int i = 0; i < 5; i++)
	{
		cout << "Enter 5 elements for the second array: ";
		cin >> arr2[i];
	}
	
	swap1(arr1, arr2);
	
}

void swap1(int *one, int *two)
{
	cout << "\n\n<-----------BEFORE SWAP FIRST ARRAY----------->\n\n";
	for(int i = 0; i < 5; i++)
	{
		cout << *(one + i) << " ";
	}
	cout << endl;
	cout << "\n\n<-----------BEFORE SWAP SECOND ARRAY----------->\n\n";
	for(int i = 0; i < 5; i++)
	{
		cout << *(two + i) << " ";
	}
	cout << endl;
	
	int temp;
	temp = *(one + 0);
	*(one + 0) = *two;
	*(two + 0) = temp;
	
	
	cout << "\n\n<-----------AFTER SWAP FIRST ARRAY----------->\n\n";
	for(int i = 0; i < 5; i++)
	{
		cout << *(one + i) << " ";
	}
	cout << endl;
	cout << "\n\n<-----------AFTER SWAP SECOND ARRAY----------->\n\n";
	for(int i = 0; i < 5; i++)
	{
		cout << *(two + i) << " ";
	}
	cout << endl;
	
}

