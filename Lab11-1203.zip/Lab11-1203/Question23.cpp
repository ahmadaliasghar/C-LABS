#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;

int main()
{
	char *ptr, *ptr1;
	
	ptr = new char[1];
	ptr1 = new char[1];
	
	cout << "Enter a string: ";
	gets(ptr);
	
	ptr1 = strcpy(ptr1, ptr);
	
	cout << ptr1;
	
	return 0;  
}

