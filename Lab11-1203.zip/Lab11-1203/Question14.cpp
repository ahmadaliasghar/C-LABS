#include<iostream>
using namespace std;

void average(float *num1, float *num2, float *num3)
{
	float avg;
	
	avg = (*num1 + *num2 + *num3) / 3;
	
	cout << "The Average of 1st, 5th, and 10th element is: " << avg << endl;
	
}

int main()
{
	float arr[10];
	float *ptr1, *ptr2, *ptr3;
	

	for(int i = 0; i < 10; i++)
	{
		cout << "Enter 10 Numbers: ";
		cin >> arr[i];
	}
	
	average(&arr[0], &arr[4], &arr[9]);
	
}
