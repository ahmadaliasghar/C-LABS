#include<iostream>
using namespace std;

bool check(int *ptr1, int *ptr2)
{
	if(*ptr1 % *ptr2 == 0)
	{
		return true;
	}
	else
		return false;
}
int main()
{
	int num1, num2;
	
	cout << "Enter first number: ";
	cin >> num1;
	
	cout << "Enter second number: ";
	cin >> num2;
	
	cout << check(&num1, &num2);
}
