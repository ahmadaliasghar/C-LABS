#include<iostream>
using namespace std;
int main()
{
	char *ptr = "Ahmad is Here";
	
	int count = 0;
	
	for(int i = 0; *(ptr + i) != '\0'; i++, count++);
	
	for(int i = 0; i < count; i++)
		cout << *(ptr + i);
		
	return 0;
}
