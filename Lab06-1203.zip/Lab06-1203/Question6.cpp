#include <iostream>
using namespace std;

void largest(int num1, int num2)
{
	(num1 > num2)? cout << num1 << " is the Largest Number" : cout << num2 <<  " is the Largest Number";
	
}

int main()
{
	int n1, n2;
	
	cout << "Enter 2 Numbers: ";
	cin >> n1 >> n2;
	
	cout << endl;
	
	largest(n1, n2);
	
	return 0;
}
