#include <iostream>
using namespace std;

int encrypt(int num)
{
	int num1, num2, num3, num4;
	
	num4 = (num % 10);
	num = num / 10;
	
	num3 = (num % 10);
	num = num / 10;
	
	num2 = (num % 10);
	num = num / 10;
	
	num1 = (num % 10);
	num = num / 10;
	
	num1 = (num1 + 3) % 10;
	num2 = (num2 + 3) % 10;
	num3 = (num3 + 3) % 10;
	num4 = (num4 + 3) % 10;
	
	return((num1 * 1000) + (num2 * 100) + (num3 * 10) + num4);
}
int decrypt(int n)
{
	int num1, num2, num3, num4;

	num4 = (n % 10);
	n = n / 10; 

	num3 = (n % 10);
	n = n / 10;

	num2 = (n % 10);
	n = n / 10;

	num1 = (n % 10);
	n = n / 10;

	num1 = (num1 - 3) % 10;
	num2 = (num2 - 3) % 10;
	num3 = (num3 - 3) % 10;
	num4 = (num4 - 3) % 10;

	return((num1 * 1000) + (num2 * 100) + (num3 * 10) + num4);
}
int main()
{
	int num;
	char ans;

	cout<<"Enter num = ";
	cin>>num;

	while(1){
		cout<<"Enter the ('e' for encrypt and 'd' for decrypt) : ";
		cin>>ans;
		if(ans=='e'||ans=='d')
		{
			break;
		}
		else{
		cout<<"Enter 'e' or 'd'"<<endl;
		}
	}

	if(ans=='e')
	{
		cout<<"Now number is = "<<encrypt(num)<<endl;
	}

	else
	{
		cout << "Now number is = " << decrypt(num) << endl;
	}

	system("pause");
	return 0;
}
