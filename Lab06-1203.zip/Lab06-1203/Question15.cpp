#include <iostream>
using namespace std;

bool checker(int num1, int num2)
{
	if(num1 % num2 == 0)
		return true;
	else
		return false;
}
int main()
{
	int n1, n2;
	
	cout << "Enter 2 Numbers: ";
	cin >> n1 >>n2;
	
	cout << checker(n1, n2) << endl;
	
	return 0;
}
