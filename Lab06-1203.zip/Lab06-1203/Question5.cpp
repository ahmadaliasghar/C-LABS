#include <iostream>
using namespace std;

float average(float num1, float num2, float num3, float num4, float num5)
{
	float result = 0;
	
	result = (num1 + num2 + num3 + num4 + num5) / 5;
	
	cout << "\nThe average of given Numbers is: " << result;
	return result;
}
int main()
{
	float num1, num2, num3, num4, num5;
	
	cout << "Enter 5 Numbers: ";
	cin >> num1 >> num2 >> num3 >> num4 >> num5;
	
	average(num1, num2, num3, num4, num5);
}

