#include <iostream>
using namespace std;

void swapValues(int num1, int num2)
{
	int temp;
	cout << "Value Before Swapping 'a' = " << num1;
	cout << "\nValue Before Swapping 'b' = " << num2;
	 
	temp = num1;
	num1 = num2;
	num2 = temp;
	
	cout << "\n\nValue After Swapping 'a' = " << num1;
	cout << "\nValue After Swapping 'b' = " << num2;
	
}
int main()
{
	int n1, n2;
	
	cout << "Enter 2 Values: ";
	cin >> n1 >> n2;
	
	swapValues(n1, n2);
	
	return 0;
}
