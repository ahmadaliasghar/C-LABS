#include <iostream>
using namespace std;

void reference(char &alpha, char &alpha1)
{
	cout << "First Chracter : " << alpha << endl;
	cout << "Second Chracter : " << alpha1 << endl;
		
} 

int main()
{
	char first, second;
	
	cout << "Enter 2 chracters: ";
	cin >> first >> second;
	
	reference(first, second); 
}
