#include <iostream>
using namespace std;

void hash(int num1, int num2, int num3, int num4, int num5)
{	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= num1; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= num2; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= num3; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= num4; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
	for(int i = 1; i <= 1; i++)
	{
		for(int a = 1; a <= num5; a++)
		{
				cout <<"#";
		}
		cout << "\n";
	}
	
}

int main()
{	
	int num1, num2, num3, num4, num5;
	
	cout << "Enter 5 Numbers: ";
	cin >> num1 >> num2 >> num3 >> num4 >> num5;
	
	cout << endl;
	
	hash(num1, num2, num3, num4, num5);
}
