#include <iostream>
using namespace std;

void star(int num)
{	
	for(int i = 0; i < num; i++)
	{
		cout << "*";
	}
	cout << endl;
}
int main()
{
	int num;

	//With Constant Value
	cout << "Using constant value: ";
	star(15);
	
	//With Variable
	cout << "\nEnter number: ";
	cin >> num;
	
	cout << "\nUsing Variable value: ";
	
	star(num);
	
}
