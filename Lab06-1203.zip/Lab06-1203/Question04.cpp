#include <iostream>
using namespace std;

int rectangle(char val, int si)
{
	int letter, size;
	for(int i = 1; i <= 6; i++)
	{
		for(int j = 1; j <= si; j++)
		{
			if((i == 1||i == 6)||(j == 1||j == si))
				cout << val;
			else
				cout << " ";
		}
	cout << endl;
	}
	return letter;
	return size;
}

int main()
{
	int size;
	char chracter;
	
	cout << "Enter a Chracter: ";
	cin >> chracter;
	
	cout << "Please, Enter Size: ";
	cin >> size;
	
	//cout << "\nWith Variable: ";
	rectangle(chracter, size);
	
	cout << endl;
	//cout << "\nWith Constants: ";
	rectangle('*', 18);
return 0;
}
