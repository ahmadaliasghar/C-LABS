#include<iostream>
using namespace std;

int add(int num1, int num2)
{
	return(num1 + num2);
}
int sub(int num1, int num2)
{
	return(num1 - num2);
}
int multi(int num1, int num2)
{
	return(num1 * num2);
}
int div(int num1, int num2)
{
	return(num1 / num2);
}
int mod(int num1, int num2)
{
	return (num1 % num2);
}
int main()
{
	int n1, n2;
	char c;
	cout << "Enter the num = ";
	cin >> n1 >> n2;
	cout << "Enter the operator(+,-,*,/,%) = ";
	cin >> c;
	if(c == '+')
	{
		cout << add(n1, n2);
	}
	else if(c == '-')
	{
		cout << sub(n1, n2);
	}
	else if(c == '*')
	{
		cout << multi(n1, n2);
	}
	else if(c == '/')
	{
		cout << div(n1, n2);
	}
	else if(c == '%')
	{
		cout << mod(n1, n2);
	}
	else{
		cout << "Not Valid Operator!!!" << endl;
	}
}


