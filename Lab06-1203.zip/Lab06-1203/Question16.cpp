#include <iostream>
using namespace std;

int check(int num1, int num2)
{
	int result;
	
	for(int i = 1; i <= num1 && i <= num2; i++)
	{
		if(num1%i==0&&num2%i==0)
		{
			result = i;
		}
	}
	return result;
}
int main()
{
	int x, y;
	
	cout << "Enter 2 values: ";
	cin >> x >> y;
	
	cout << "\nGreatest Common Divisor : " << check(x, y);
	
	return 0;
}
