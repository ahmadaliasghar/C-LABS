#include <iostream>
using namespace std;

float addition(float num1, float num2, float num3, float num4, float num5)
{
	return (num1 + num2 + num3 + num4 + num5);
}

float multiplication(float num1, float num2, float num3, float num4, float num5)
{
	return (num1 * num2 * num3 * num4 * num5);
}

int main()
{
	float n1, n2, n3, n4, n5;
	n1 = 1.4;
	n2 = 2.5;
	n3 = 3.6;
	n4 = 4.7;
	n5 = 5.8;
	
	//With Constant Values
	cout << "Using constant values: ";
	cout << addition(1.8, 2.7, 3.6, 4.5, 5.4);
	//With Variables
	cout << "\nUsing valiables values: ";
	cout << addition(n1, n2, n3, n4, n5);
	//With Constant Values
	cout << "\nUsing constant values: ";
	cout << multiplication(1, 2, 3, 4, 5);
	//With Variables
	cout << "\nUsing variables values: ";
	cout << multiplication(n1, n2, n3, n4, n5);

}

