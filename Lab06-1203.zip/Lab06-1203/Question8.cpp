#include <iostream>
using namespace std;

int fact(int num)
{
	int fact;
	
	fact = 1;
	
	for(int i = 1; i<=num; i++)
	{
		fact = fact*i;
	}
	cout << "The factorial of " << num << " is : " << fact;

	return fact;
}
int main()
{
	int num;
	
	cout << "Enter a number to calculate its factorial: ";
	cin >> num;
	
	fact(num);
}
