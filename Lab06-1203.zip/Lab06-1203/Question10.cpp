#include <iostream>
#include <math.h>
using namespace std;

float add(float num1, float num2, float num3, float num4, float num5)
{
	return (num1 + num2 + num3 + num4 + num5);
}


int main()
{
float n1, n2, n3, n4, n5;
float add = 0;

cout << "Enter 5 Numbers to calculate its average: ";
cin >> n1 >> n2 >> n3 >> n4 >> n5;

add = (n1 + n2 + n3 + n4 + n5) / 5;


cout << "\nAverage is : " << add << endl;

return 0;

	
}
