#include <iostream>
using namespace std;

float area(float rad)
{
	float area = 0;
	float pie = 3.1416;
	
	area = pie * rad * rad;
	
	cout << "\nArea of the circle is: " << area << endl;
	
	return area;
}

int main()
{
	float r;
	r = 1;
	
	cout << "Enter the radius of the circle: ";
	cin >> r;
	
	area(r);
}
