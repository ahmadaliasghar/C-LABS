#include <iostream>
using namespace std;

int main()
{
	int num;
	int &ref = num;
	
	float num1;
	float &ref1 = num1;
	
	char letter;
	char &ref2 = letter;
	
	cout << "Enter integer value: ";
	cin >> ref;
	
	cout << "Enter float value: ";
	cin >> ref1;
	
	cout << "Enter character value: ";
	cin >> ref2;
	
	cout << "The integer value is: " << num << endl;
	cout << "The float value is: " << num1 << endl;
	cout << "The character value is: " << letter << endl;

	return 0;
} 

