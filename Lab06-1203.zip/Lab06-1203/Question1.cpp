#include <iostream>
using namespace std;

void letter(); 

int main()
{
	letter();
}

void letter()
{
	char letter;
	
	cout << "Enter the character: ";
	cin >> letter;
	
	if(letter>='a'&&letter<='z')
	{
		cout << "\n\""<< letter << "\" is a small letter." << endl;
	}
	else if(letter>='A'&&letter<='Z')
	{
		cout << "\n\""<< letter << "\" is a large letter." << endl;
	}
	else 
		cout << "\n Not a letter!!!" << endl;
}
